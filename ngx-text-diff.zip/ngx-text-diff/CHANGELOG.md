## NgxTextDiff - v0.6.0
* Added support for Angular 9

## NgxTextDiff - v0.5.4
* Allowed overriding CSS and allowed user to pass in classes or styles (#18).
* Added @Output() to provide comparison data in case user wants it (#17).
* Added better usage examples to the README (#15).

## NgxTextDiff - v0.5.3
* Added support to Angular v7 (#10).
* Fixed incorrect line numbers (#8).

## NgxTextDiff - v0.5.2
* Changed some inputs name and fixed spell errors.

## NgxTextDiff - v0.5.0
* First Alpha Version
