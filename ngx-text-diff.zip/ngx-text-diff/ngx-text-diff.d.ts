/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { FormatLinePipe as ɵc } from './lib/format-line.pipe';
export { LoaderSpinnerComponent as ɵb } from './lib/loader-spinner/loader-spinner.component';
export { ContainerDirective as ɵa } from './lib/ngx-text-diff-container.directive';

//# sourceMappingURL=ngx-text-diff.d.ts.map