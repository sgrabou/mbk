import * as i0 from '@angular/core';
import { Injectable, Directive, ElementRef, Input, EventEmitter, Component, ChangeDetectorRef, ViewChildren, Output, Pipe, NgModule } from '@angular/core';
import { DIFF_INSERT, DIFF_DELETE, DIFF_EQUAL, diff_match_patch } from 'diff-match-patch';
import { __awaiter } from 'tslib';
import 'rxjs';
import { ScrollDispatcher, ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

const isNil = val => val === undefined || val === null;
const isEmpty = val => val == null || !(Object.keys(val) || val).length || (Object.keys(val) || val).length === 0;

class NgxTextDiffFormatterService {
    constructor(diffParser) {
        this.diffParser = diffParser;
    }
    initializeCounters() {
        this.leftCounter = 1;
        this.rightCounter = 1;
    }
    formatOutput(diffs) {
        this.initializeCounters();
        const result = [];
        for (let index = 0; index < diffs.length; index++) {
            const [diffType, diffValue] = diffs[index];
            const [nextType, nextValue] = diffs.length - 1 > index ? diffs[index + 1] : [];
            switch (diffType) {
                case DIFF_EQUAL:
                    this.createEqualRowResults(result, diffValue);
                    break;
                case DIFF_DELETE:
                    if (nextType === DIFF_INSERT) {
                        this.createMergeRowResults(result, diffValue, nextValue);
                        index += 1;
                    }
                    else {
                        this.createDeleteRowResults(result, diffValue);
                    }
                    break;
                case DIFF_INSERT:
                    if (nextType === DIFF_DELETE) {
                        this.createMergeRowResults(result, diffValue, nextValue);
                        index += 1;
                    }
                    else {
                        this.createInsertRowResults(result, diffValue);
                    }
                    break;
            }
        }
        return result;
    }
    createEqualRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: {
                    lineNumber: this.leftCounter,
                    lineContent: line,
                    lineDiffs: [],
                    prefix: '',
                },
                rightContent: {
                    lineNumber: this.rightCounter,
                    lineContent: line,
                    lineDiffs: [],
                    prefix: '',
                },
                belongTo: 'both',
                hasDiffs: false,
                numDiffs: 0,
            });
            this.leftCounter = this.leftCounter + 1;
            this.rightCounter = this.rightCounter + 1;
        });
    }
    createDeleteRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: {
                    lineNumber: this.leftCounter,
                    lineContent: line,
                    lineDiffs: [{ content: line, isDiff: true }],
                    prefix: '-',
                },
                rightContent: null,
                hasDiffs: true,
                belongTo: 'left',
                numDiffs: 1,
            });
            this.leftCounter = this.leftCounter + 1;
        });
    }
    createInsertRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: null,
                rightContent: {
                    lineNumber: this.rightCounter,
                    lineContent: line,
                    lineDiffs: [{ content: line, isDiff: true }],
                    prefix: '+',
                },
                hasDiffs: true,
                belongTo: 'right',
                numDiffs: 1,
            });
            this.rightCounter = this.rightCounter + 1;
        });
    }
    createMergeRowResults(result, oldValue, newValue) {
        const beforeLines = this.getLines(oldValue);
        const afterLines = this.getLines(newValue);
        const longestLength = Math.max(beforeLines.length, afterLines.length);
        for (let index = 0; index < longestLength; index++) {
            if (beforeLines[index] != null && afterLines[index] != null) {
                this.mergeResults(result, beforeLines[index], afterLines[index]);
            }
            else if (beforeLines[index] != null) {
                this.createDeleteRowResults(result, beforeLines[index]);
            }
            else if (afterLines[index] != null) {
                this.createInsertRowResults(result, afterLines[index]);
            }
        }
    }
    getLines(diffValue) {
        return diffValue
            .split('\n')
            .filter((value, index, array) => index !== array.length - 1 || !isEmpty(value));
    }
    mergeResults(result, leftLine, rightLine) {
        const entry = {
            leftContent: {
                lineNumber: this.leftCounter,
                lineContent: leftLine,
                lineDiffs: this.getDiffParts(leftLine, rightLine),
                prefix: '-',
            },
            rightContent: null,
            hasDiffs: true,
            belongTo: 'both',
            numDiffs: 1,
        };
        entry.rightContent = {
            lineNumber: this.rightCounter,
            lineContent: rightLine,
            lineDiffs: this.getDiffParts(rightLine, leftLine),
            prefix: '+',
        };
        entry.numDiffs = this.countDiffs(entry);
        this.leftCounter = this.leftCounter + 1;
        this.rightCounter = this.rightCounter + 1;
        result.push(entry);
    }
    getDiffParts(value, compareValue) {
        const diffs = this.diffParser.diff_main(value, compareValue);
        return diffs.filter(([type]) => type !== DIFF_INSERT).map(([type, content]) => ({ content, isDiff: type !== DIFF_EQUAL }));
    }
    countDiffs(result) {
        let diffCount = 0;
        if (result.leftContent) {
            diffCount += result.leftContent.lineDiffs.filter(diff => diff.isDiff).length;
        }
        if (result.rightContent) {
            diffCount += result.rightContent.lineDiffs.filter(diff => diff.isDiff).length;
        }
        return diffCount;
    }
}

class NgxTextDiffService {
    constructor() {
        this.initParser();
    }
    initParser() {
        this.diffParser = new diff_match_patch();
    }
    getDiffsByLines(left, right) {
        return new Promise((resolve, reject) => {
            const a = this.diffParser.diff_linesToChars_(left, right);
            const lineText1 = a.chars1;
            const lineText2 = a.chars2;
            const linesArray = a.lineArray;
            const diffs = this.diffParser.diff_main(lineText1, lineText2, true);
            this.diffParser.diff_charsToLines_(diffs, linesArray);
            const formatter = new NgxTextDiffFormatterService(this.diffParser);
            const rows = formatter.formatOutput(diffs);
            if (!rows) {
                reject('Error');
            }
            resolve(rows);
        });
    }
}
NgxTextDiffService.ɵprov = i0.ɵɵdefineInjectable({ factory: function NgxTextDiffService_Factory() { return new NgxTextDiffService(); }, token: NgxTextDiffService, providedIn: "root" });
NgxTextDiffService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
NgxTextDiffService.ctorParameters = () => [];

class ContainerDirective {
    constructor(_el) {
        this._el = _el;
        this.element = _el.nativeElement;
    }
}
ContainerDirective.decorators = [
    { type: Directive, args: [{
                selector: '[tdContainer]',
            },] }
];
ContainerDirective.ctorParameters = () => [
    { type: ElementRef }
];
ContainerDirective.propDecorators = {
    id: [{ type: Input }]
};

class NgxTextDiffComponent {
    constructor(scrollService, diff, cd) {
        this.scrollService = scrollService;
        this.diff = diff;
        this.cd = cd;
        this._hideMatchingLines = false;
        this.format = 'SideBySide';
        this.left = '';
        this.right = '';
        this.loading = false;
        this.showToolbar = true;
        this.showBtnToolbar = true;
        this.synchronizeScrolling = true;
        this.compareResults = new EventEmitter();
        this.subscriptions = [];
        this.tableRows = [];
        this.filteredTableRows = [];
        this.tableRowsLineByLine = [];
        this.filteredTableRowsLineByLine = [];
        this.diffsCount = 0;
        this.formatOptions = [
            {
                id: 'side-by-side',
                name: 'side-by-side',
                label: 'Side by Side',
                value: 'SideBySide',
                icon: 'la-code',
            },
            {
                id: 'line-by-line',
                name: 'line-by-line',
                label: 'Line by Line',
                value: 'LineByLine',
                icon: 'la-file-text',
            },
        ];
    }
    get hideMatchingLines() {
        return this._hideMatchingLines;
    }
    set hideMatchingLines(hide) {
        this.hideMatchingLinesChanged(hide);
    }
    ngOnInit() {
        this.loading = true;
        if (this.diffContent) {
            this.subscriptions.push(this.diffContent.subscribe(content => {
                this.loading = true;
                this.left = content.leftContent;
                this.right = content.rightContent;
                this.renderDiffs()
                    .then(() => {
                    this.cd.detectChanges();
                    this.loading = false;
                })
                    .catch(() => (this.loading = false));
            }));
        }
        this.renderDiffs()
            .then(() => (this.loading = false))
            .catch(e => (this.loading = false));
    }
    ngAfterViewInit() {
        this.initScrollListener();
    }
    ngOnDestroy() {
        if (this.subscriptions) {
            this.subscriptions.forEach(subscription => subscription.unsubscribe());
        }
    }
    hideMatchingLinesChanged(value) {
        this._hideMatchingLines = value;
        if (this.hideMatchingLines) {
            this.filteredTableRows = this.tableRows.filter(row => (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'));
            this.filteredTableRowsLineByLine = this.tableRowsLineByLine.filter(row => (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'));
        }
        else {
            this.filteredTableRows = this.tableRows;
            this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
        }
    }
    setDiffTableFormat(format) {
        this.format = format;
    }
    renderDiffs() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.diffsCount = 0;
                this.tableRows = yield this.diff.getDiffsByLines(this.left, this.right);
                this.tableRowsLineByLine = this.tableRows.reduce((tableLineByLine, row) => {
                    if (!tableLineByLine) {
                        tableLineByLine = [];
                    }
                    if (row.hasDiffs) {
                        if (row.leftContent) {
                            tableLineByLine.push({
                                leftContent: row.leftContent,
                                rightContent: null,
                                belongTo: row.belongTo,
                                hasDiffs: true,
                                numDiffs: row.numDiffs,
                            });
                        }
                        if (row.rightContent) {
                            tableLineByLine.push({
                                leftContent: null,
                                rightContent: row.rightContent,
                                belongTo: row.belongTo,
                                hasDiffs: true,
                                numDiffs: row.numDiffs,
                            });
                        }
                    }
                    else {
                        tableLineByLine.push(row);
                    }
                    return tableLineByLine;
                }, []);
                this.diffsCount = this.tableRows.filter(row => row.hasDiffs).length;
                this.filteredTableRows = this.tableRows;
                this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
                this.emitCompareResultsEvent();
            }
            catch (e) {
                throw e;
            }
        });
    }
    emitCompareResultsEvent() {
        const diffResults = {
            hasDiff: this.diffsCount > 0,
            diffsCount: this.diffsCount,
            rowsWithDiff: this.tableRows
                .filter(row => row.hasDiffs)
                .map(row => ({
                leftLineNumber: row.leftContent ? row.leftContent.lineNumber : null,
                rightLineNumber: row.rightContent ? row.rightContent.lineNumber : null,
                numDiffs: row.numDiffs,
            })),
        };
        this.compareResults.next(diffResults);
    }
    trackTableRows(index, row) {
        return row && row.leftContent ? row.leftContent.lineContent : row && row.rightContent ? row.rightContent.lineContent : undefined;
    }
    trackDiffs(index, diff) {
        return diff && diff.content ? diff.content : undefined;
    }
    initScrollListener() {
        this.subscriptions.push(this.scrollService.scrolled().subscribe((scrollableEv) => {
            if (scrollableEv && this.synchronizeScrolling) {
                const scrollableId = scrollableEv.getElementRef().nativeElement.id;
                const nonScrolledContainer = this.containers.find(container => container.id !== scrollableId);
                if (nonScrolledContainer) {
                    nonScrolledContainer.element.scrollTo({
                        top: scrollableEv.measureScrollOffset('top'),
                        left: scrollableEv.measureScrollOffset('left'),
                    });
                }
            }
        }));
    }
}
NgxTextDiffComponent.decorators = [
    { type: Component, args: [{
                selector: 'td-ngx-text-diff',
                template: "<td-loader-spinner [active]=\"loading\"></td-loader-spinner>\n<div class=\"td-wrapper\" [ngClass]=\"outerContainerClass\" [ngStyle]=\"outerContainerStyle\" *ngIf=\"!loading\">\n\n  <div [ngClass]=\"toolbarClass\" [ngStyle]=\"toolbarStyle\" *ngIf=\"showToolbar\">\n    <div class=\"td-toolbar-show-diff\">\n      <label class=\"td-checkbox-container\">\n        Only Show Lines with Differences ({{ diffsCount }})\n        <input type=\"checkbox\" id=\"showDiffs\" [ngModel]=\"hideMatchingLines\" (ngModelChange)=\"hideMatchingLinesChanged($event)\" />\n        <span class=\"checkmark\"></span>\n      </label>\n    </div>\n  </div>\n\n  <div class=\"td-toolbar-select-format\" *ngIf=\"showToolbar && showBtnToolbar\">\n    <div class=\"td-btn-group td-btn-group-toggle\" data-toggle=\"buttons\">\n      <button\n        *ngFor=\"let option of formatOptions\"\n        [ngClass]=\"{ active: format === option.value, disabled: !!option.disabled }\"\n        [name]=\"option.name\"\n        [id]=\"option.id\"\n        [disabled]=\"!!option.disabled\"\n        (click)=\"setDiffTableFormat(option.value)\"\n      >\n        {{ option.label }}\n      </button>\n    </div>\n  </div>\n\n  <div class=\"td-table-wrapper\" [ngClass]=\"compareRowsClass\" [ngStyle]=\"compareRowsStyle\">\n    <!-- Right side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-left-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              {{ row.leftContent?.lineNumber !== -1 ? row.leftContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              <span>{{ row.leftContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Left side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-right-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              {{ row.rightContent?.lineNumber !== -1 ? row.rightContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              <span>{{ row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.rightContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Line By Line - combined table -->\n    <div class=\"td-table-container line-by-line\" *ngIf=\"format === 'LineByLine'\">\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRowsLineByLine; trackBy: trackTableRows\">\n            <td scope=\"row\" class=\"fit-column line-number-col-left\">{{ row.leftContent?.lineNumber }}</td>\n            <td scope=\"row\" class=\"fit-column line-number-col\">{{ row.rightContent?.lineNumber }}</td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n            >\n              <span>{{ row.leftContent?.prefix || row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.leftContent && row.leftContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.rightContent && row.rightContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n</div>\n",
                styles: [".td-wrapper{background-color:#fff;color:#444;display:grid;grid-row-gap:10px;grid-template-columns:repeat(2,[col] 50%);grid-template-rows:repeat(2,[row] auto);width:100%}.td-toolbar-show-diff{grid-column:1;grid-row:1}.td-toolbar-select-format{grid-column:2;grid-row:1;margin-left:auto}.td-table-container{grid-column:1/2;grid-row:2;max-width:100%;overflow-x:auto;width:100%}.td-table-wrapper{display:flex;width:200%}.td-table{border:1px solid #a9a9a9;max-height:50vh;max-width:100%;width:100%}.fit-column{white-space:nowrap;width:1px}.line-number-col{border-right:1px solid #ddd;left:0;position:relative;position:sticky;top:auto}.line-number-col,.line-number-col-left{background-color:#f7f7f7;color:#999;font-size:87.5%;padding-left:10px;padding-right:10px;text-align:right}.insert-row,.insert-row>.line-number-col{background-color:#dfd;border-color:#b4e2b4}.delete-row,.delete-row>.line-number-col{background-color:#fee8e9;border-color:#e9aeae}.empty-row{background-color:#f7f7f7;height:24px}.td-table td{border-top:0;max-width:50%;padding-bottom:0;padding-top:0;white-space:nowrap}pre{margin-bottom:0}td.content-col{line-height:24px;margin:0;padding:0}td.prefix-col{line-height:24px;padding-left:10px;padding-right:10px}.td-btn-group{border-radius:4px}.td-btn-group button{background-color:rgba(23,162,184,.7);border:1px solid #17a2b8;color:#fff;cursor:pointer;float:left}.td-btn-group button:not(:last-child){border-right:none}.td-btn-group button:first-child{-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px;-webkit-border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-bottom-left-radius:4px;border-top-left-radius:4px}.td-btn-group button:last-child{-moz-border-radius-bottomright:4px;-moz-border-radius-topright:4px;-webkit-border-bottom-right-radius:4px;-webkit-border-top-right-radius:4px;border-bottom-right-radius:4px;border-top-right-radius:4px}.td-btn-group:after{clear:both;content:\"\";display:table}.td-btn-group button.active,.td-btn-group button:hover{background-color:#17a2b8}.td-checkbox-container{-moz-user-select:none;-webkit-user-select:none;cursor:pointer;display:block;font-size:16px;line-height:28px;margin-bottom:0;padding-left:21px;position:relative;user-select:none}.td-checkbox-container input{cursor:pointer;height:0;opacity:0;position:absolute;width:0}.checkmark{background-color:#eee;height:16px;left:0;position:absolute;top:7px;width:16px}.td-checkbox-container:hover input~.checkmark{background-color:#ccc}.td-checkbox-container input:checked~.checkmark{background-color:#17a2b8}.checkmark:after{content:\"\";display:none;position:absolute}.td-checkbox-container input:checked~.checkmark:after{display:block}.td-checkbox-container .checkmark:after{border:solid #fff;border-width:0 3px 3px 0;height:10px;left:5px;top:3px;transform:rotate(45deg);width:5px}.insert-row>.highlight{background-color:#acf2bd!important}.delete-row>.highlight{background-color:#fdb8c0!important}"]
            },] }
];
NgxTextDiffComponent.ctorParameters = () => [
    { type: ScrollDispatcher },
    { type: NgxTextDiffService },
    { type: ChangeDetectorRef }
];
NgxTextDiffComponent.propDecorators = {
    containers: [{ type: ViewChildren, args: [ContainerDirective,] }],
    format: [{ type: Input }],
    left: [{ type: Input }],
    right: [{ type: Input }],
    diffContent: [{ type: Input }],
    loading: [{ type: Input }],
    showToolbar: [{ type: Input }],
    showBtnToolbar: [{ type: Input }],
    hideMatchingLines: [{ type: Input }],
    outerContainerClass: [{ type: Input }],
    outerContainerStyle: [{ type: Input }],
    toolbarClass: [{ type: Input }],
    toolbarStyle: [{ type: Input }],
    compareRowsClass: [{ type: Input }],
    compareRowsStyle: [{ type: Input }],
    synchronizeScrolling: [{ type: Input }],
    compareResults: [{ type: Output }]
};

class LoaderSpinnerComponent {
    constructor() {
        this.active = false;
    }
    ngOnInit() { }
}
LoaderSpinnerComponent.decorators = [
    { type: Component, args: [{
                selector: 'td-loader-spinner',
                template: "<div class=\"td-loading-roller\" *ngIf=\"active\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n</div>\n",
                styles: [".td-loading-roller{display:inline-block;height:64px;position:relative;width:64px}.td-loading-roller div{-webkit-animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;transform-origin:32px 32px}.td-loading-roller div:after{background:#000;border-radius:50%;content:\" \";display:block;height:6px;margin:-3px 0 0 -3px;position:absolute;width:6px}.td-loading-roller div:first-child{-webkit-animation-delay:-36ms;animation-delay:-36ms}.td-loading-roller div:first-child:after{left:50px;top:50px}.td-loading-roller div:nth-child(2){-webkit-animation-delay:-72ms;animation-delay:-72ms}.td-loading-roller div:nth-child(2):after{left:45px;top:54px}.td-loading-roller div:nth-child(3){-webkit-animation-delay:-.108s;animation-delay:-.108s}.td-loading-roller div:nth-child(3):after{left:39px;top:57px}.td-loading-roller div:nth-child(4){-webkit-animation-delay:-.144s;animation-delay:-.144s}.td-loading-roller div:nth-child(4):after{left:32px;top:58px}.td-loading-roller div:nth-child(5){-webkit-animation-delay:-.18s;animation-delay:-.18s}.td-loading-roller div:nth-child(5):after{left:25px;top:57px}.td-loading-roller div:nth-child(6){-webkit-animation-delay:-.216s;animation-delay:-.216s}.td-loading-roller div:nth-child(6):after{left:19px;top:54px}.td-loading-roller div:nth-child(7){-webkit-animation-delay:-.252s;animation-delay:-.252s}.td-loading-roller div:nth-child(7):after{left:14px;top:50px}.td-loading-roller div:nth-child(8){-webkit-animation-delay:-.288s;animation-delay:-.288s}.td-loading-roller div:nth-child(8):after{left:10px;top:45px}@-webkit-keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}"]
            },] }
];
LoaderSpinnerComponent.ctorParameters = () => [];
LoaderSpinnerComponent.propDecorators = {
    active: [{ type: Input }]
};

class FormatLinePipe {
    transform(line, diffs) {
        if (!line) {
            return ' ';
        }
        if (!!diffs && diffs.length > 0) {
            /*diffs.forEach(diff => {
              line = line.replace(diff, `<span class="highli">${diff}</span>`);
            });*/
        }
        return line
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/ /g, '&nbsp;');
    }
}
FormatLinePipe.decorators = [
    { type: Pipe, args: [{
                name: 'formatLine'
            },] }
];

class NgxTextDiffModule {
}
NgxTextDiffModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule, FormsModule, ScrollingModule],
                declarations: [NgxTextDiffComponent, LoaderSpinnerComponent, FormatLinePipe, ContainerDirective],
                exports: [NgxTextDiffComponent],
            },] }
];

/*
 * Public API Surface of ngx-text-diff
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxTextDiffComponent, NgxTextDiffModule, NgxTextDiffService, ContainerDirective as ɵa, LoaderSpinnerComponent as ɵb, FormatLinePipe as ɵc };
//# sourceMappingURL=ngx-text-diff.js.map
