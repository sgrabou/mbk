import { Diff, diff_match_patch } from 'diff-match-patch';
import { DiffTableRowResult } from './ngx-text-diff.model';
export declare class NgxTextDiffFormatterService {
    private diffParser;
    private leftCounter;
    private rightCounter;
    constructor(diffParser: diff_match_patch);
    private initializeCounters;
    formatOutput(diffs: Diff[]): DiffTableRowResult[];
    private createEqualRowResults;
    private createDeleteRowResults;
    private createInsertRowResults;
    private createMergeRowResults;
    private getLines;
    private mergeResults;
    private getDiffParts;
    private countDiffs;
}
