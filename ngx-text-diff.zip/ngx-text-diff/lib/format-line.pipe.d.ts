import { PipeTransform } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class FormatLinePipe implements PipeTransform {
    transform(line: string, diffs?: string[]): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormatLinePipe, never>;
    static ɵpipe: ɵngcc0.ɵɵPipeDefWithMeta<FormatLinePipe, "formatLine">;
}

//# sourceMappingURL=format-line.pipe.d.ts.map