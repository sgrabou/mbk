import { ElementRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class ContainerDirective {
    private _el;
    id: string;
    element: HTMLTableHeaderCellElement;
    constructor(_el: ElementRef);
    static ɵfac: ɵngcc0.ɵɵFactoryDef<ContainerDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<ContainerDirective, "[tdContainer]", never, { "id": "id"; }, {}, never>;
}

//# sourceMappingURL=ngx-text-diff-container.directive.d.ts.map