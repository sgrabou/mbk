export declare const isNil: (val: any) => boolean;
export declare const isEmpty: (val: any) => boolean;
