package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.mapper;

import java.util.ArrayList;
import java.util.List;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.ProtocolMapperModel;
import org.keycloak.models.UserSessionModel;
import org.keycloak.protocol.oidc.mappers.AbstractOIDCProtocolMapper;
import org.keycloak.protocol.oidc.mappers.OIDCAccessTokenMapper;
import org.keycloak.protocol.oidc.mappers.OIDCAttributeMapperHelper;
import org.keycloak.protocol.oidc.mappers.OIDCIDTokenMapper;
import org.keycloak.protocol.oidc.mappers.UserInfoTokenMapper;
import org.keycloak.provider.ProviderConfigProperty;
import org.keycloak.representations.IDToken;

public class BnpINetMapper extends AbstractOIDCProtocolMapper implements OIDCAccessTokenMapper, OIDCIDTokenMapper, UserInfoTokenMapper {
  private static final List<ProviderConfigProperty> configProperties = new ArrayList<>();
  
  public static final String PROVIDER_ID = "oidc-bnpinet-mapper";
  
  static {
    OIDCAttributeMapperHelper.addTokenClaimNameConfig(configProperties);
    OIDCAttributeMapperHelper.addIncludeInTokensConfig(configProperties, BnpINetMapper.class);
  }
  
  public String getDisplayCategory() {
    return "Token mapper";
  }
  
  public String getDisplayType() {
    return "BNPINET Mapper";
  }
  
  public String getHelpText() {
    return "Adds informations about the user to the claim";
  }
  
  public List<ProviderConfigProperty> getConfigProperties() {
    return configProperties;
  }
  
  public String getId() {
    return "oidc-bnpinet-mapper";
  }
  
  protected void setClaim(IDToken token, ProtocolMapperModel mappingModel, UserSessionModel userSession, KeycloakSession keycloakSession) {
    token.setOtherClaims("id_cbs", userSession.getUser().getFirstAttribute("ID_CBS"));
    token.setOtherClaims("cr_c", userSession.getUser().getFirstAttribute("CR_C"));
  }
}
