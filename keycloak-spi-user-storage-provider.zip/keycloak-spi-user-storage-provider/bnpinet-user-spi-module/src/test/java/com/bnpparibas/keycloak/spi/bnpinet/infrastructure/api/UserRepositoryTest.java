package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.api;

public class UserRepositoryTest {
    public static void main(String[] args) {
        UserRepository repository = new UserRepository("http://localhost:9090/api/v1");
        boolean connected = repository.validateCredentials("merchantTest", "123456");

    }
}
