package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.provider;

import com.bnpparibas.keycloak.spi.bnpinet.infrastructure.api.UserRepository;
import java.util.List;
import org.keycloak.Config;
import org.keycloak.component.ComponentModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.provider.ProviderConfigProperty;
import org.keycloak.provider.ProviderConfigurationBuilder;
import org.keycloak.storage.UserStorageProviderFactory;

public class BnpINetUserStorageProviderFactory implements UserStorageProviderFactory<BnpINetUserStorageProvider> {
  private String urlBnpinetAPI;
  
  public void init(Config.Scope config) {}
  
  public BnpINetUserStorageProvider create(KeycloakSession session, ComponentModel model) {
    this.urlBnpinetAPI = (String)model.getConfig().getFirst("urlBnpinetAPI");
    UserRepository repository = new UserRepository(this.urlBnpinetAPI);
    return new BnpINetUserStorageProvider(session, model, repository);
  }
  
  public String getId() {
    return "bnpinet-user-provider";
  }
  
  public List<ProviderConfigProperty> getConfigProperties() {
    return ProviderConfigurationBuilder.create().property().name("urlBnpinetAPI").label("BNPINET API URL").type("String").defaultValue("http://localhost:9090/auth/api/v2").add().build();
  }
}
