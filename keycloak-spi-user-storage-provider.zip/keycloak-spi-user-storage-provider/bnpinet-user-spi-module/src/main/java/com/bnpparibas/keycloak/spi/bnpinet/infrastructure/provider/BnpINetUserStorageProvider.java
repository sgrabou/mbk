package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.provider;

import com.bnpparibas.keycloak.spi.bnpinet.infrastructure.adapter.BnpINetUserAdapter;
import com.bnpparibas.keycloak.spi.bnpinet.infrastructure.api.UserRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.keycloak.component.ComponentModel;
import org.keycloak.credential.CredentialInput;
import org.keycloak.credential.CredentialInputUpdater;
import org.keycloak.credential.CredentialInputValidator;
import org.keycloak.models.GroupModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.RoleModel;
import org.keycloak.models.UserCredentialModel;
import org.keycloak.models.UserModel;
import org.keycloak.storage.UserStorageProvider;
import org.keycloak.storage.user.UserLookupProvider;
import org.keycloak.storage.user.UserQueryProvider;
import org.keycloak.storage.user.UserRegistrationProvider;

public class BnpINetUserStorageProvider implements UserStorageProvider, UserRegistrationProvider, UserLookupProvider, UserQueryProvider, CredentialInputUpdater, CredentialInputValidator {
  private final KeycloakSession session;
  
  private final ComponentModel model;
  
  private final UserRepository repository;
  
  public BnpINetUserStorageProvider(KeycloakSession session, ComponentModel model, UserRepository repository) {
    this.session = session;
    this.model = model;
    this.repository = repository;
  }
  
  public boolean supportsCredentialType(String credentialType) {
    return "password".equals(credentialType);
  }
  
  public boolean isConfiguredFor(RealmModel realm, UserModel user, String credentialType) {
    return supportsCredentialType(credentialType);
  }

  public boolean isValid(RealmModel realm, UserModel user, CredentialInput input) {
    System.out.println("isValid user credential: userId={0}" + user.getId());
    if (!supportsCredentialType(input.getType()) || !(input instanceof UserCredentialModel))
      return false;
    UserCredentialModel cred = (UserCredentialModel)input;
    return this.repository.validateCredentials(user.getUsername(), cred.getValue());
  }
  
  public boolean updateCredential(RealmModel realm, UserModel user, CredentialInput input) {
    return false;
  }
  
  public void disableCredentialType(RealmModel realm, UserModel user, String credentialType) {}
  
  public Set<String> getDisableableCredentialTypes(RealmModel realm, UserModel user) {
    return Collections.emptySet();
  }
  
  public void preRemove(RealmModel realm) {
    System.out.println("pre-remove realm");
  }
  
  public void preRemove(RealmModel realm, GroupModel group) {
    System.out.println("pre-remove group");
  }
  
  public void preRemove(RealmModel realm, RoleModel role) {
    System.out.println("pre-remove role");
  }
  
  public void close() {
    System.out.println("closing");
  }
  
  public UserModel getUserById(String id, RealmModel realm) {
    System.out.println("lookup user by userId : " + id);
    return null;
  }
  
  public UserModel getUserByUsername(String username, RealmModel realm) {
    System.out.println("lookup user by username : " + username);
    return (UserModel)new BnpINetUserAdapter(this.session, realm, this.model, this.repository.findUserByUsername(username).toDomain());
  }
  
  public UserModel getUserByEmail(String email, RealmModel realm) {
    System.out.println("lookup user by username: realm={0} email={1}" + email);
    return getUserByUsername(email, realm);
  }
  
  public int getUsersCount(RealmModel realm) {
    return 0;
  }
  
  public List<UserModel> getUsers(RealmModel realm) {
    System.out.println("list users: realm={0}" + realm.getId());
    return Collections.emptyList();
  }
  
  public List<UserModel> getUsers(RealmModel realm, int firstResult, int maxResults) {
    return getUsers(realm);
  }
  
  public List<UserModel> searchForUser(String search, RealmModel realm) {
    return new ArrayList<>();
  }
  
  public List<UserModel> searchForUser(String search, RealmModel realm, int firstResult, int maxResults) {
    return searchForUser(search, realm);
  }
  
  public List<UserModel> searchForUser(Map<String, String> params, RealmModel realm) {
    return Collections.emptyList();
  }
  
  public List<UserModel> searchForUser(Map<String, String> params, RealmModel realm, int firstResult, int maxResults) {
    return Collections.emptyList();
  }
  
  public List<UserModel> getGroupMembers(RealmModel realm, GroupModel group, int firstResult, int maxResults) {
    return Collections.emptyList();
  }
  
  public List<UserModel> getGroupMembers(RealmModel realm, GroupModel group) {
    return Collections.emptyList();
  }
  
  public List<UserModel> searchForUserByUserAttribute(String attrName, String attrValue, RealmModel realm) {
    return Collections.emptyList();
  }
  
  public UserModel addUser(RealmModel realmModel, String s) {
    return null;
  }
  
  public boolean removeUser(RealmModel realmModel, UserModel userModel) {
    return false;
  }
}
