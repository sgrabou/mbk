package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.api;

import com.bnpparibas.keycloak.spi.bnpinet.infrastructure.model.User;

public class UserResponse {
  private String id;
  
  private String idsCBS;
  
  private String customerCode;
  
  private String username;
  
  private String firstName;
  
  private String lastName;
  
  private String email;
  
  public String getIdsCBS() {
    return this.idsCBS;
  }
  
  public void setIdsCBS(String idsCBS) {
    this.idsCBS = idsCBS;
  }
  
  public String getCustomerCode() {
    return this.customerCode;
  }
  
  public void setCustomerCode(String customerCode) {
    this.customerCode = customerCode;
  }
  
  public String getId() {
    return this.id;
  }
  
  public void setId(String id) {
    this.id = id;
  }
  
  public String getUsername() {
    return this.username;
  }
  
  public void setUsername(String username) {
    this.username = username;
  }
  
  public String getFirstName() {
    return this.firstName;
  }
  
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  
  public String getLastName() {
    return this.lastName;
  }
  
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public User toDomain() {
    User user = new User();
    user.setFirstName(getFirstName());
    user.setLastName(getLastName());
    user.setEmail(getEmail());
    user.setId(getId());
    user.setUsername(getUsername());
    user.setIdCbs(getIdsCBS());
    user.setCustomerCode(getCustomerCode());
    user.setPassword("dummy");
    return user;
  }
}
