package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.adapter;

import com.bnpparibas.keycloak.spi.bnpinet.infrastructure.model.User;

import org.keycloak.component.ComponentModel;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.storage.StorageId;
import org.keycloak.storage.adapter.AbstractUserAdapterFederatedStorage;

public class BnpINetUserAdapter extends AbstractUserAdapterFederatedStorage {
  private final User user;
  
  private final String keycloakId;
  
  public BnpINetUserAdapter(KeycloakSession session, RealmModel realm, ComponentModel model, User user) {
    super(session, realm, model);
    this.user = user;
    this.keycloakId = StorageId.keycloakId(model, user.getId());
    setSingleAttribute("ID_CBS", user.getIdCbs());
    setSingleAttribute("CR_C", user.getCustomerCode());
  }
  
  public String getId() {
    return this.keycloakId;
  }
  
  public String getUsername() {
    return this.user.getUsername();
  }
  
  public void setUsername(String username) {
    this.user.setUsername(username);
  }
  
  public String getEmail() {
    return this.user.getEmail();
  }
  
  public void setEmail(String email) {
    this.user.setEmail(email);
  }
  
  public String getFirstName() {
    return this.user.getFirstName();
  }
  
  public void setFirstName(String firstName) {
    this.user.setFirstName(firstName);
  }
  
  public String getLastName() {
    return this.user.getLastName();
  }
  
  public void setLastName(String lastName) {
    this.user.setLastName(lastName);
  }
}
