package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.api;

import org.springframework.http.HttpEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class UserRepository {
  private RestTemplate restTemplate;
  
  private String urlAPIBnpinet;
  
  public UserRepository(String urlAPIBnpinet) {
    ClientHttpRequestFactory requestFactory = getClientHttpRequestFactory();
    this.restTemplate = new RestTemplate();
    this.urlAPIBnpinet = urlAPIBnpinet;
  }
  
  public UserResponse findUserByUsername(String username) {
    UserResponse userResponse = new UserResponse();
    try {
      userResponse = (UserResponse)this.restTemplate.getForObject(this.urlAPIBnpinet + "/users/" + username, UserResponse.class, new Object[0]);
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return userResponse;
  }
  
  public boolean validateCredentials(String username, String password) {
    HttpEntity<AuthRequest> request = new HttpEntity(new AuthRequest(username, password));
    try {
      this.restTemplate.postForObject(this.urlAPIBnpinet + "/login", request, UserResponse.class, new Object[0]);
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    } 
    return true;
  }
  
  private ClientHttpRequestFactory getClientHttpRequestFactory() {
    int timeout = 5000;
    HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
    clientHttpRequestFactory.setConnectTimeout(timeout);
    return (ClientHttpRequestFactory)clientHttpRequestFactory;
  }
}
