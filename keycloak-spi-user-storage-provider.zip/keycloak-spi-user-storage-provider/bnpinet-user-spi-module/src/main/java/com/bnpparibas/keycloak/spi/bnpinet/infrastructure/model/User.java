package com.bnpparibas.keycloak.spi.bnpinet.infrastructure.model;

public class User {
  private String id;
  
  private String username;
  
  private String email;
  
  private String firstName;
  
  private String lastName;
  
  private String password;
  
  private String idCbs;
  
  private String customerCode;
  
  public String getId() {
    return this.id;
  }
  
  public void setId(String id) {
    this.id = id;
  }
  
  public String getUsername() {
    return this.username;
  }
  
  public void setUsername(String username) {
    this.username = username;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getFirstName() {
    return this.firstName;
  }
  
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }
  
  public String getLastName() {
    return this.lastName;
  }
  
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
  
  public String getPassword() {
    return this.password;
  }
  
  public void setPassword(String password) {
    this.password = password;
  }
  
  public String getIdCbs() {
    return this.idCbs;
  }
  
  public void setIdCbs(String idCbs) {
    this.idCbs = idCbs;
  }
  
  public String getCustomerCode() {
    return this.customerCode;
  }
  
  public void setCustomerCode(String customerCode) {
    this.customerCode = customerCode;
  }
}
