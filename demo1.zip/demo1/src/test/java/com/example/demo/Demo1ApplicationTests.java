package com.example.demo;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1ApplicationTests {

    @InjectMocks
    PostTransferImpl postTransfer;

    @Test
    void contextLoads() {
        postTransfer.checkStatus("123455");
    }

}
