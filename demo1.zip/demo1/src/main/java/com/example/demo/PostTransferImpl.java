package com.example.demo;


import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;


@Service
public class PostTransferImpl {
    private static final Logger logger = Logger.getLogger(UpdateStatus.class.getName());

    public void checkStatus(String transferID) {
        // Mettre ici toute la logique pour executer un virement instantané
        System.out.println("Hello: Virement instantané exécuté !!");

       //Recuperer le statut en asychrone
        CompletableFuture<Object> updateStatusFuture = retryUpdateStatusWithBackoff( "12334323", 1, 3,3,3,5,5,7,7);

        // ici on lance le traitement pour vérifier le status
        System.out.println("Virement exécuté !!");
    }



    private CompletableFuture<Object> retryUpdateStatusWithBackoff(String transferID, int... retryIntervalsInMinutes) {
        CompletableFuture<Object> future = CompletableFuture.completedFuture(null);
        int maxRetries =retryIntervalsInMinutes.length;
        for (int retryCount = 0; retryCount < maxRetries; retryCount++) {
            final int retryDelayMinutes = retryIntervalsInMinutes[Math.min(retryCount, retryIntervalsInMinutes.length - 1)];
            final int currentRetryCount = retryCount;
            future = future
                    .thenComposeAsync(ignoredResult -> retryUpdateWithDelay(retryDelayMinutes, transferID))
                    .thenApply(result -> {
                        if (result) {
                            // Exit the loop when result is `true`.
                            throw new CompletionException(new RuntimeException("Update successful. No more retries needed."));
                        }
                        return currentRetryCount; // Continue with the next retry.
                    });
        }

        return future.exceptionally(throwable -> {
            // Handle the exception when the loop exits.
            logger.info("future killed !");

            if (throwable.getCause() instanceof RuntimeException) {
                System.out.println(throwable.getCause().getMessage());
            }

            return null;
        });
    }

    private CompletableFuture<Boolean> retryUpdateWithDelay(int delayMinutes, String transferID) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                TimeUnit.SECONDS.sleep(delayMinutes);
                boolean result = UpdateStatus.updateStatus(transferID);
                return result; // Return `true` if the update is successful, `false` otherwise.
            } catch (InterruptedException e) {
                throw new RuntimeException("Retry operation was interrupted", e);
            }
        });
    }

}
