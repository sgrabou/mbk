package com.example.demo;


import org.apache.commons.logging.Log;

import java.util.Random;
import java.util.logging.Logger;

import static com.sun.activation.registries.LogSupport.log;

public class UpdateStatus {
    private static final Logger logger = Logger.getLogger(UpdateStatus.class.getName());

    public static boolean updateStatus(String transferID) {
        double probabilityOfFalse = 0.85; // 90% chance of false
        Random random = new Random();
        boolean randomValue = random.nextDouble() > probabilityOfFalse;
        if(randomValue) {
            logger.info("Statut de virement modifié");
        } else {
            logger.info("Impossible de recupérer le status de virement, reessayer plutard !!");

        }
     return randomValue;
    }
}
