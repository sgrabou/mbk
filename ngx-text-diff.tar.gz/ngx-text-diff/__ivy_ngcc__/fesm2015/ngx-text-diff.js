import * as i0 from '@angular/core';
import { Injectable, Directive, ElementRef, Input, EventEmitter, Component, ChangeDetectorRef, ViewChildren, Output, Pipe, NgModule } from '@angular/core';
import { DIFF_INSERT, DIFF_DELETE, DIFF_EQUAL, diff_match_patch } from 'diff-match-patch';
import { __awaiter } from 'tslib';
import 'rxjs';
import { ScrollDispatcher, ScrollingModule } from '@angular/cdk/scrolling';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from '@angular/cdk/scrolling';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';

function NgxTextDiffComponent_div_1_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r7 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "div", 9);
    ɵngcc0.ɵɵelementStart(1, "div", 10);
    ɵngcc0.ɵɵelementStart(2, "label", 11);
    ɵngcc0.ɵɵtext(3);
    ɵngcc0.ɵɵelementStart(4, "input", 12);
    ɵngcc0.ɵɵlistener("ngModelChange", function NgxTextDiffComponent_div_1_div_1_Template_input_ngModelChange_4_listener($event) { ɵngcc0.ɵɵrestoreView(_r7); const ctx_r6 = ɵngcc0.ɵɵnextContext(2); return ctx_r6.hideMatchingLinesChanged($event); });
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelement(5, "span", 13);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = ɵngcc0.ɵɵnextContext(2);
    ɵngcc0.ɵɵproperty("ngClass", ctx_r1.toolbarClass)("ngStyle", ctx_r1.toolbarStyle);
    ɵngcc0.ɵɵadvance(3);
    ɵngcc0.ɵɵtextInterpolate1(" Only Show Lines with Differences (", ctx_r1.diffsCount, ") ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngModel", ctx_r1.hideMatchingLines);
} }
const _c0 = function (a0, a1) { return { active: a0, disabled: a1 }; };
function NgxTextDiffComponent_div_1_div_2_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r11 = ɵngcc0.ɵɵgetCurrentView();
    ɵngcc0.ɵɵelementStart(0, "button", 17);
    ɵngcc0.ɵɵlistener("click", function NgxTextDiffComponent_div_1_div_2_button_2_Template_button_click_0_listener() { ɵngcc0.ɵɵrestoreView(_r11); const option_r9 = ctx.$implicit; const ctx_r10 = ɵngcc0.ɵɵnextContext(3); return ctx_r10.setDiffTableFormat(option_r9.value); });
    ɵngcc0.ɵɵtext(1);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const option_r9 = ctx.$implicit;
    const ctx_r8 = ɵngcc0.ɵɵnextContext(3);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(5, _c0, ctx_r8.format === option_r9.value, !!option_r9.disabled))("name", option_r9.name)("id", option_r9.id)("disabled", !!option_r9.disabled);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", option_r9.label, " ");
} }
function NgxTextDiffComponent_div_1_div_2_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 14);
    ɵngcc0.ɵɵelementStart(1, "div", 15);
    ɵngcc0.ɵɵtemplate(2, NgxTextDiffComponent_div_1_div_2_button_2_Template, 2, 8, "button", 16);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = ɵngcc0.ɵɵnextContext(2);
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵproperty("ngForOf", ctx_r2.formatOptions);
} }
const _c1 = function (a0, a1) { return { "delete-row": a0, "empty-row": a1 }; };
function NgxTextDiffComponent_div_1_div_4_tr_3_td_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵelement(1, "span", 25);
    ɵngcc0.ɵɵpipe(2, "formatLine");
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r13 = ɵngcc0.ɵɵnextContext().$implicit;
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(4, _c1, (row_r13.leftContent == null ? null : row_r13.leftContent.prefix) === "-", !(row_r13.leftContent == null ? null : row_r13.leftContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(2, 2, row_r13.leftContent == null ? null : row_r13.leftContent.lineContent), ɵngcc0.ɵɵsanitizeHtml);
} }
const _c2 = function (a0) { return { highlight: a0 }; };
function NgxTextDiffComponent_div_1_div_4_tr_3_td_7_span_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "span", 27);
    ɵngcc0.ɵɵpipe(1, "formatLine");
} if (rf & 2) {
    const diff_r18 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(1, 2, diff_r18.content), ɵngcc0.ɵɵsanitizeHtml)("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c2, diff_r18.isDiff));
} }
function NgxTextDiffComponent_div_1_div_4_tr_3_td_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_div_4_tr_3_td_7_span_1_Template, 2, 6, "span", 26);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r13 = ɵngcc0.ɵɵnextContext().$implicit;
    const ctx_r15 = ɵngcc0.ɵɵnextContext(3);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(3, _c1, (row_r13.leftContent == null ? null : row_r13.leftContent.prefix) === "-", !(row_r13.leftContent == null ? null : row_r13.leftContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngForOf", row_r13.leftContent == null ? null : row_r13.leftContent.lineDiffs)("ngForTrackBy", ctx_r15.trackDiffs);
} }
function NgxTextDiffComponent_div_1_div_4_tr_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "tr");
    ɵngcc0.ɵɵelementStart(1, "td", 21);
    ɵngcc0.ɵɵtext(2);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementStart(3, "td", 22);
    ɵngcc0.ɵɵelementStart(4, "span");
    ɵngcc0.ɵɵtext(5);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵtemplate(6, NgxTextDiffComponent_div_1_div_4_tr_3_td_6_Template, 3, 7, "td", 23);
    ɵngcc0.ɵɵtemplate(7, NgxTextDiffComponent_div_1_div_4_tr_3_td_7_Template, 2, 6, "td", 23);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r13 = ctx.$implicit;
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(6, _c1, (row_r13.leftContent == null ? null : row_r13.leftContent.prefix) === "-", !(row_r13.leftContent == null ? null : row_r13.leftContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", (row_r13.leftContent == null ? null : row_r13.leftContent.lineNumber) !== 0 - 1 ? row_r13.leftContent == null ? null : row_r13.leftContent.lineNumber : " ", " ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(9, _c1, (row_r13.leftContent == null ? null : row_r13.leftContent.prefix) === "-", !(row_r13.leftContent == null ? null : row_r13.leftContent.lineContent)));
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate((row_r13.leftContent == null ? null : row_r13.leftContent.prefix) || " ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", !row_r13.hasDiffs);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", row_r13.hasDiffs);
} }
function NgxTextDiffComponent_div_1_div_4_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 18);
    ɵngcc0.ɵɵelementStart(1, "table", 19);
    ɵngcc0.ɵɵelementStart(2, "tbody");
    ɵngcc0.ɵɵtemplate(3, NgxTextDiffComponent_div_1_div_4_tr_3_Template, 8, 12, "tr", 20);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = ɵngcc0.ɵɵnextContext(2);
    ɵngcc0.ɵɵadvance(3);
    ɵngcc0.ɵɵproperty("ngForOf", ctx_r3.filteredTableRows)("ngForTrackBy", ctx_r3.trackTableRows);
} }
const _c3 = function (a0, a1) { return { "insert-row": a0, "empty-row": a1 }; };
function NgxTextDiffComponent_div_1_div_5_tr_3_td_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵelement(1, "span", 25);
    ɵngcc0.ɵɵpipe(2, "formatLine");
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r21 = ɵngcc0.ɵɵnextContext().$implicit;
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(4, _c3, (row_r21.rightContent == null ? null : row_r21.rightContent.prefix) === "+", !(row_r21.rightContent == null ? null : row_r21.rightContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(2, 2, row_r21.rightContent == null ? null : row_r21.rightContent.lineContent), ɵngcc0.ɵɵsanitizeHtml);
} }
function NgxTextDiffComponent_div_1_div_5_tr_3_td_7_span_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "span", 27);
    ɵngcc0.ɵɵpipe(1, "formatLine");
} if (rf & 2) {
    const diff_r26 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(1, 2, diff_r26.content), ɵngcc0.ɵɵsanitizeHtml)("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c2, diff_r26.isDiff));
} }
function NgxTextDiffComponent_div_1_div_5_tr_3_td_7_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_div_5_tr_3_td_7_span_1_Template, 2, 6, "span", 26);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r21 = ɵngcc0.ɵɵnextContext().$implicit;
    const ctx_r23 = ɵngcc0.ɵɵnextContext(3);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(3, _c3, (row_r21.rightContent == null ? null : row_r21.rightContent.prefix) === "+", !(row_r21.rightContent == null ? null : row_r21.rightContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngForOf", row_r21.rightContent == null ? null : row_r21.rightContent.lineDiffs)("ngForTrackBy", ctx_r23.trackDiffs);
} }
function NgxTextDiffComponent_div_1_div_5_tr_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "tr");
    ɵngcc0.ɵɵelementStart(1, "td", 21);
    ɵngcc0.ɵɵtext(2);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementStart(3, "td", 22);
    ɵngcc0.ɵɵelementStart(4, "span");
    ɵngcc0.ɵɵtext(5);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵtemplate(6, NgxTextDiffComponent_div_1_div_5_tr_3_td_6_Template, 3, 7, "td", 23);
    ɵngcc0.ɵɵtemplate(7, NgxTextDiffComponent_div_1_div_5_tr_3_td_7_Template, 2, 6, "td", 23);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r21 = ctx.$implicit;
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(6, _c3, (row_r21.rightContent == null ? null : row_r21.rightContent.prefix) === "+", !(row_r21.rightContent == null ? null : row_r21.rightContent.lineContent)));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵtextInterpolate1(" ", (row_r21.rightContent == null ? null : row_r21.rightContent.lineNumber) !== 0 - 1 ? row_r21.rightContent == null ? null : row_r21.rightContent.lineNumber : " ", " ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(9, _c3, (row_r21.rightContent == null ? null : row_r21.rightContent.prefix) === "+", !(row_r21.rightContent == null ? null : row_r21.rightContent.lineContent)));
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate((row_r21.rightContent == null ? null : row_r21.rightContent.prefix) || " ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", !row_r21.hasDiffs);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", row_r21.hasDiffs);
} }
function NgxTextDiffComponent_div_1_div_5_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 28);
    ɵngcc0.ɵɵelementStart(1, "table", 19);
    ɵngcc0.ɵɵelementStart(2, "tbody");
    ɵngcc0.ɵɵtemplate(3, NgxTextDiffComponent_div_1_div_5_tr_3_Template, 8, 12, "tr", 20);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r4 = ɵngcc0.ɵɵnextContext(2);
    ɵngcc0.ɵɵadvance(3);
    ɵngcc0.ɵɵproperty("ngForOf", ctx_r4.filteredTableRows)("ngForTrackBy", ctx_r4.trackTableRows);
} }
const _c4 = function (a0, a1) { return { "delete-row": a0, "insert-row": a1 }; };
function NgxTextDiffComponent_div_1_div_6_tr_3_td_8_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵelement(1, "span", 25);
    ɵngcc0.ɵɵpipe(2, "formatLine");
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r29 = ɵngcc0.ɵɵnextContext().$implicit;
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(4, _c4, (row_r29.leftContent == null ? null : row_r29.leftContent.prefix) === "-", (row_r29.rightContent == null ? null : row_r29.rightContent.prefix) === "+"));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(2, 2, row_r29.leftContent == null ? null : row_r29.leftContent.lineContent), ɵngcc0.ɵɵsanitizeHtml);
} }
function NgxTextDiffComponent_div_1_div_6_tr_3_td_9_span_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "span", 27);
    ɵngcc0.ɵɵpipe(1, "formatLine");
} if (rf & 2) {
    const diff_r35 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(1, 2, diff_r35.content), ɵngcc0.ɵɵsanitizeHtml)("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c2, diff_r35.isDiff));
} }
function NgxTextDiffComponent_div_1_div_6_tr_3_td_9_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_div_6_tr_3_td_9_span_1_Template, 2, 6, "span", 26);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r29 = ɵngcc0.ɵɵnextContext().$implicit;
    const ctx_r31 = ɵngcc0.ɵɵnextContext(3);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(3, _c4, (row_r29.leftContent == null ? null : row_r29.leftContent.prefix) === "-", (row_r29.rightContent == null ? null : row_r29.rightContent.prefix) === "+"));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngForOf", row_r29.leftContent == null ? null : row_r29.leftContent.lineDiffs)("ngForTrackBy", ctx_r31.trackDiffs);
} }
function NgxTextDiffComponent_div_1_div_6_tr_3_td_10_span_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelement(0, "span", 27);
    ɵngcc0.ɵɵpipe(1, "formatLine");
} if (rf & 2) {
    const diff_r38 = ctx.$implicit;
    ɵngcc0.ɵɵproperty("innerHTML", ɵngcc0.ɵɵpipeBind1(1, 2, diff_r38.content), ɵngcc0.ɵɵsanitizeHtml)("ngClass", ɵngcc0.ɵɵpureFunction1(4, _c2, diff_r38.isDiff));
} }
function NgxTextDiffComponent_div_1_div_6_tr_3_td_10_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "td", 24);
    ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_div_6_tr_3_td_10_span_1_Template, 2, 6, "span", 26);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r29 = ɵngcc0.ɵɵnextContext().$implicit;
    const ctx_r32 = ɵngcc0.ɵɵnextContext(3);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(3, _c4, (row_r29.leftContent == null ? null : row_r29.leftContent.prefix) === "-", (row_r29.rightContent == null ? null : row_r29.rightContent.prefix) === "+"));
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngForOf", row_r29.rightContent == null ? null : row_r29.rightContent.lineDiffs)("ngForTrackBy", ctx_r32.trackDiffs);
} }
function NgxTextDiffComponent_div_1_div_6_tr_3_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "tr");
    ɵngcc0.ɵɵelementStart(1, "td", 30);
    ɵngcc0.ɵɵtext(2);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementStart(3, "td", 31);
    ɵngcc0.ɵɵtext(4);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementStart(5, "td", 22);
    ɵngcc0.ɵɵelementStart(6, "span");
    ɵngcc0.ɵɵtext(7);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵtemplate(8, NgxTextDiffComponent_div_1_div_6_tr_3_td_8_Template, 3, 7, "td", 23);
    ɵngcc0.ɵɵtemplate(9, NgxTextDiffComponent_div_1_div_6_tr_3_td_9_Template, 2, 6, "td", 23);
    ɵngcc0.ɵɵtemplate(10, NgxTextDiffComponent_div_1_div_6_tr_3_td_10_Template, 2, 6, "td", 23);
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r29 = ctx.$implicit;
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate(row_r29.leftContent == null ? null : row_r29.leftContent.lineNumber);
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate(row_r29.rightContent == null ? null : row_r29.rightContent.lineNumber);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ɵngcc0.ɵɵpureFunction2(7, _c4, (row_r29.leftContent == null ? null : row_r29.leftContent.prefix) === "-", (row_r29.rightContent == null ? null : row_r29.rightContent.prefix) === "+"));
    ɵngcc0.ɵɵadvance(2);
    ɵngcc0.ɵɵtextInterpolate((row_r29.leftContent == null ? null : row_r29.leftContent.prefix) || (row_r29.rightContent == null ? null : row_r29.rightContent.prefix) || " ");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", !row_r29.hasDiffs);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", row_r29.hasDiffs && row_r29.leftContent && (row_r29.leftContent == null ? null : row_r29.leftContent.lineDiffs.length) !== 0);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", row_r29.hasDiffs && row_r29.rightContent && (row_r29.rightContent == null ? null : row_r29.rightContent.lineDiffs.length) !== 0);
} }
function NgxTextDiffComponent_div_1_div_6_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 29);
    ɵngcc0.ɵɵelementStart(1, "table", 19);
    ɵngcc0.ɵɵelementStart(2, "tbody");
    ɵngcc0.ɵɵtemplate(3, NgxTextDiffComponent_div_1_div_6_tr_3_Template, 11, 10, "tr", 20);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r5 = ɵngcc0.ɵɵnextContext(2);
    ɵngcc0.ɵɵadvance(3);
    ɵngcc0.ɵɵproperty("ngForOf", ctx_r5.filteredTableRowsLineByLine)("ngForTrackBy", ctx_r5.trackTableRows);
} }
function NgxTextDiffComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 2);
    ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_div_1_Template, 6, 4, "div", 3);
    ɵngcc0.ɵɵtemplate(2, NgxTextDiffComponent_div_1_div_2_Template, 3, 1, "div", 4);
    ɵngcc0.ɵɵelementStart(3, "div", 5);
    ɵngcc0.ɵɵtemplate(4, NgxTextDiffComponent_div_1_div_4_Template, 4, 2, "div", 6);
    ɵngcc0.ɵɵtemplate(5, NgxTextDiffComponent_div_1_div_5_Template, 4, 2, "div", 7);
    ɵngcc0.ɵɵtemplate(6, NgxTextDiffComponent_div_1_div_6_Template, 4, 2, "div", 8);
    ɵngcc0.ɵɵelementEnd();
    ɵngcc0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r0 = ɵngcc0.ɵɵnextContext();
    ɵngcc0.ɵɵproperty("ngClass", ctx_r0.outerContainerClass)("ngStyle", ctx_r0.outerContainerStyle);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.showToolbar);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.showToolbar && ctx_r0.showBtnToolbar);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngClass", ctx_r0.compareRowsClass)("ngStyle", ctx_r0.compareRowsStyle);
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.format === "SideBySide");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.format === "SideBySide");
    ɵngcc0.ɵɵadvance(1);
    ɵngcc0.ɵɵproperty("ngIf", ctx_r0.format === "LineByLine");
} }
function LoaderSpinnerComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    ɵngcc0.ɵɵelementStart(0, "div", 1);
    ɵngcc0.ɵɵelement(1, "div");
    ɵngcc0.ɵɵelement(2, "div");
    ɵngcc0.ɵɵelement(3, "div");
    ɵngcc0.ɵɵelement(4, "div");
    ɵngcc0.ɵɵelement(5, "div");
    ɵngcc0.ɵɵelement(6, "div");
    ɵngcc0.ɵɵelement(7, "div");
    ɵngcc0.ɵɵelement(8, "div");
    ɵngcc0.ɵɵelementEnd();
} }
const isNil = val => val === undefined || val === null;
const isEmpty = val => val == null || !(Object.keys(val) || val).length || (Object.keys(val) || val).length === 0;

class NgxTextDiffFormatterService {
    constructor(diffParser) {
        this.diffParser = diffParser;
    }
    initializeCounters() {
        this.leftCounter = 1;
        this.rightCounter = 1;
    }
    formatOutput(diffs) {
        this.initializeCounters();
        const result = [];
        for (let index = 0; index < diffs.length; index++) {
            const [diffType, diffValue] = diffs[index];
            const [nextType, nextValue] = diffs.length - 1 > index ? diffs[index + 1] : [];
            switch (diffType) {
                case DIFF_EQUAL:
                    this.createEqualRowResults(result, diffValue);
                    break;
                case DIFF_DELETE:
                    if (nextType === DIFF_INSERT) {
                        this.createMergeRowResults(result, diffValue, nextValue);
                        index += 1;
                    }
                    else {
                        this.createDeleteRowResults(result, diffValue);
                    }
                    break;
                case DIFF_INSERT:
                    if (nextType === DIFF_DELETE) {
                        this.createMergeRowResults(result, diffValue, nextValue);
                        index += 1;
                    }
                    else {
                        this.createInsertRowResults(result, diffValue);
                    }
                    break;
            }
        }
        return result;
    }
    createEqualRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: {
                    lineNumber: this.leftCounter,
                    lineContent: line,
                    lineDiffs: [],
                    prefix: '',
                },
                rightContent: {
                    lineNumber: this.rightCounter,
                    lineContent: line,
                    lineDiffs: [],
                    prefix: '',
                },
                belongTo: 'both',
                hasDiffs: false,
                numDiffs: 0,
            });
            this.leftCounter = this.leftCounter + 1;
            this.rightCounter = this.rightCounter + 1;
        });
    }
    createDeleteRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: {
                    lineNumber: this.leftCounter,
                    lineContent: line,
                    lineDiffs: [{ content: line, isDiff: true }],
                    prefix: '-',
                },
                rightContent: null,
                hasDiffs: true,
                belongTo: 'left',
                numDiffs: 1,
            });
            this.leftCounter = this.leftCounter + 1;
        });
    }
    createInsertRowResults(result, diffValue) {
        const lines = this.getLines(diffValue);
        lines.forEach(line => {
            result.push({
                leftContent: null,
                rightContent: {
                    lineNumber: this.rightCounter,
                    lineContent: line,
                    lineDiffs: [{ content: line, isDiff: true }],
                    prefix: '+',
                },
                hasDiffs: true,
                belongTo: 'right',
                numDiffs: 1,
            });
            this.rightCounter = this.rightCounter + 1;
        });
    }
    createMergeRowResults(result, oldValue, newValue) {
        const beforeLines = this.getLines(oldValue);
        const afterLines = this.getLines(newValue);
        const longestLength = Math.max(beforeLines.length, afterLines.length);
        for (let index = 0; index < longestLength; index++) {
            if (beforeLines[index] != null && afterLines[index] != null) {
                this.mergeResults(result, beforeLines[index], afterLines[index]);
            }
            else if (beforeLines[index] != null) {
                this.createDeleteRowResults(result, beforeLines[index]);
            }
            else if (afterLines[index] != null) {
                this.createInsertRowResults(result, afterLines[index]);
            }
        }
    }
    getLines(diffValue) {
        return diffValue
            .split('\n')
            .filter((value, index, array) => index !== array.length - 1 || !isEmpty(value));
    }
    mergeResults(result, leftLine, rightLine) {
        const entry = {
            leftContent: {
                lineNumber: this.leftCounter,
                lineContent: leftLine,
                lineDiffs: this.getDiffParts(leftLine, rightLine),
                prefix: '-',
            },
            rightContent: null,
            hasDiffs: true,
            belongTo: 'both',
            numDiffs: 1,
        };
        entry.rightContent = {
            lineNumber: this.rightCounter,
            lineContent: rightLine,
            lineDiffs: this.getDiffParts(rightLine, leftLine),
            prefix: '+',
        };
        entry.numDiffs = this.countDiffs(entry);
        this.leftCounter = this.leftCounter + 1;
        this.rightCounter = this.rightCounter + 1;
        result.push(entry);
    }
    getDiffParts(value, compareValue) {
        const diffs = this.diffParser.diff_main(value, compareValue);
        return diffs.filter(([type]) => type !== DIFF_INSERT).map(([type, content]) => ({ content, isDiff: type !== DIFF_EQUAL }));
    }
    countDiffs(result) {
        let diffCount = 0;
        if (result.leftContent) {
            diffCount += result.leftContent.lineDiffs.filter(diff => diff.isDiff).length;
        }
        if (result.rightContent) {
            diffCount += result.rightContent.lineDiffs.filter(diff => diff.isDiff).length;
        }
        return diffCount;
    }
}

class NgxTextDiffService {
    constructor() {
        this.initParser();
    }
    initParser() {
        this.diffParser = new diff_match_patch();
    }
    getDiffsByLines(left, right) {
        return new Promise((resolve, reject) => {
            const a = this.diffParser.diff_linesToChars_(left, right);
            const lineText1 = a.chars1;
            const lineText2 = a.chars2;
            const linesArray = a.lineArray;
            const diffs = this.diffParser.diff_main(lineText1, lineText2, true);
            this.diffParser.diff_charsToLines_(diffs, linesArray);
            const formatter = new NgxTextDiffFormatterService(this.diffParser);
            const rows = formatter.formatOutput(diffs);
            if (!rows) {
                reject('Error');
            }
            resolve(rows);
        });
    }
}
NgxTextDiffService.ɵfac = function NgxTextDiffService_Factory(t) { return new (t || NgxTextDiffService)(); };
NgxTextDiffService.ɵprov = i0.ɵɵdefineInjectable({ factory: function NgxTextDiffService_Factory() { return new NgxTextDiffService(); }, token: NgxTextDiffService, providedIn: "root" });
NgxTextDiffService.ctorParameters = () => [];
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(NgxTextDiffService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();

class ContainerDirective {
    constructor(_el) {
        this._el = _el;
        this.element = _el.nativeElement;
    }
}
ContainerDirective.ɵfac = function ContainerDirective_Factory(t) { return new (t || ContainerDirective)(ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ElementRef)); };
ContainerDirective.ɵdir = ɵngcc0.ɵɵdefineDirective({ type: ContainerDirective, selectors: [["", "tdContainer", ""]], inputs: { id: "id" } });
ContainerDirective.ctorParameters = () => [
    { type: ElementRef }
];
ContainerDirective.propDecorators = {
    id: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(ContainerDirective, [{
        type: Directive,
        args: [{
                selector: '[tdContainer]'
            }]
    }], function () { return [{ type: ɵngcc0.ElementRef }]; }, { id: [{
            type: Input
        }] }); })();

class NgxTextDiffComponent {
    constructor(scrollService, diff, cd) {
        this.scrollService = scrollService;
        this.diff = diff;
        this.cd = cd;
        this._hideMatchingLines = false;
        this.format = 'SideBySide';
        this.left = '';
        this.right = '';
        this.loading = false;
        this.showToolbar = true;
        this.showBtnToolbar = true;
        this.synchronizeScrolling = true;
        this.compareResults = new EventEmitter();
        this.subscriptions = [];
        this.tableRows = [];
        this.filteredTableRows = [];
        this.tableRowsLineByLine = [];
        this.filteredTableRowsLineByLine = [];
        this.diffsCount = 0;
        this.formatOptions = [
            {
                id: 'side-by-side',
                name: 'side-by-side',
                label: 'Side by Side',
                value: 'SideBySide',
                icon: 'la-code',
            },
            {
                id: 'line-by-line',
                name: 'line-by-line',
                label: 'Line by Line',
                value: 'LineByLine',
                icon: 'la-file-text',
            },
        ];
    }
    get hideMatchingLines() {
        return this._hideMatchingLines;
    }
    set hideMatchingLines(hide) {
        this.hideMatchingLinesChanged(hide);
    }
    ngOnInit() {
        this.loading = true;
        if (this.diffContent) {
            this.subscriptions.push(this.diffContent.subscribe(content => {
                this.loading = true;
                this.left = content.leftContent;
                this.right = content.rightContent;
                this.renderDiffs()
                    .then(() => {
                    this.cd.detectChanges();
                    this.loading = false;
                })
                    .catch(() => (this.loading = false));
            }));
        }
        this.renderDiffs()
            .then(() => (this.loading = false))
            .catch(e => (this.loading = false));
    }
    ngAfterViewInit() {
        this.initScrollListener();
    }
    ngOnDestroy() {
        if (this.subscriptions) {
            this.subscriptions.forEach(subscription => subscription.unsubscribe());
        }
    }
    hideMatchingLinesChanged(value) {
        this._hideMatchingLines = value;
        if (this.hideMatchingLines) {
            this.filteredTableRows = this.tableRows.filter(row => (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'));
            this.filteredTableRowsLineByLine = this.tableRowsLineByLine.filter(row => (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'));
        }
        else {
            this.filteredTableRows = this.tableRows;
            this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
        }
    }
    setDiffTableFormat(format) {
        this.format = format;
    }
    renderDiffs() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.diffsCount = 0;
                this.tableRows = yield this.diff.getDiffsByLines(this.left, this.right);
                this.tableRowsLineByLine = this.tableRows.reduce((tableLineByLine, row) => {
                    if (!tableLineByLine) {
                        tableLineByLine = [];
                    }
                    if (row.hasDiffs) {
                        if (row.leftContent) {
                            tableLineByLine.push({
                                leftContent: row.leftContent,
                                rightContent: null,
                                belongTo: row.belongTo,
                                hasDiffs: true,
                                numDiffs: row.numDiffs,
                            });
                        }
                        if (row.rightContent) {
                            tableLineByLine.push({
                                leftContent: null,
                                rightContent: row.rightContent,
                                belongTo: row.belongTo,
                                hasDiffs: true,
                                numDiffs: row.numDiffs,
                            });
                        }
                    }
                    else {
                        tableLineByLine.push(row);
                    }
                    return tableLineByLine;
                }, []);
                this.diffsCount = this.tableRows.filter(row => row.hasDiffs).length;
                this.filteredTableRows = this.tableRows;
                this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
                this.emitCompareResultsEvent();
            }
            catch (e) {
                throw e;
            }
        });
    }
    emitCompareResultsEvent() {
        const diffResults = {
            hasDiff: this.diffsCount > 0,
            diffsCount: this.diffsCount,
            rowsWithDiff: this.tableRows
                .filter(row => row.hasDiffs)
                .map(row => ({
                leftLineNumber: row.leftContent ? row.leftContent.lineNumber : null,
                rightLineNumber: row.rightContent ? row.rightContent.lineNumber : null,
                numDiffs: row.numDiffs,
            })),
        };
        this.compareResults.next(diffResults);
    }
    trackTableRows(index, row) {
        return row && row.leftContent ? row.leftContent.lineContent : row && row.rightContent ? row.rightContent.lineContent : undefined;
    }
    trackDiffs(index, diff) {
        return diff && diff.content ? diff.content : undefined;
    }
    initScrollListener() {
        this.subscriptions.push(this.scrollService.scrolled().subscribe((scrollableEv) => {
            if (scrollableEv && this.synchronizeScrolling) {
                const scrollableId = scrollableEv.getElementRef().nativeElement.id;
                const nonScrolledContainer = this.containers.find(container => container.id !== scrollableId);
                if (nonScrolledContainer) {
                    nonScrolledContainer.element.scrollTo({
                        top: scrollableEv.measureScrollOffset('top'),
                        left: scrollableEv.measureScrollOffset('left'),
                    });
                }
            }
        }));
    }
}
NgxTextDiffComponent.ɵfac = function NgxTextDiffComponent_Factory(t) { return new (t || NgxTextDiffComponent)(ɵngcc0.ɵɵdirectiveInject(ɵngcc1.ScrollDispatcher), ɵngcc0.ɵɵdirectiveInject(NgxTextDiffService), ɵngcc0.ɵɵdirectiveInject(ɵngcc0.ChangeDetectorRef)); };
NgxTextDiffComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: NgxTextDiffComponent, selectors: [["td-ngx-text-diff"]], viewQuery: function NgxTextDiffComponent_Query(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵviewQuery(ContainerDirective, true);
    } if (rf & 2) {
        var _t;
        ɵngcc0.ɵɵqueryRefresh(_t = ɵngcc0.ɵɵloadQuery()) && (ctx.containers = _t);
    } }, inputs: { format: "format", left: "left", right: "right", loading: "loading", showToolbar: "showToolbar", showBtnToolbar: "showBtnToolbar", synchronizeScrolling: "synchronizeScrolling", hideMatchingLines: "hideMatchingLines", diffContent: "diffContent", outerContainerClass: "outerContainerClass", outerContainerStyle: "outerContainerStyle", toolbarClass: "toolbarClass", toolbarStyle: "toolbarStyle", compareRowsClass: "compareRowsClass", compareRowsStyle: "compareRowsStyle" }, outputs: { compareResults: "compareResults" }, decls: 2, vars: 2, consts: [[3, "active"], ["class", "td-wrapper", 3, "ngClass", "ngStyle", 4, "ngIf"], [1, "td-wrapper", 3, "ngClass", "ngStyle"], [3, "ngClass", "ngStyle", 4, "ngIf"], ["class", "td-toolbar-select-format", 4, "ngIf"], [1, "td-table-wrapper", 3, "ngClass", "ngStyle"], ["class", "td-table-container side-by-side", "id", "td-left-compare-container", "tdContainer", "", "cdkScrollable", "", 4, "ngIf"], ["class", "td-table-container side-by-side", "id", "td-right-compare-container", "tdContainer", "", "cdkScrollable", "", 4, "ngIf"], ["class", "td-table-container line-by-line", 4, "ngIf"], [3, "ngClass", "ngStyle"], [1, "td-toolbar-show-diff"], [1, "td-checkbox-container"], ["type", "checkbox", "id", "showDiffs", 3, "ngModel", "ngModelChange"], [1, "checkmark"], [1, "td-toolbar-select-format"], ["data-toggle", "buttons", 1, "td-btn-group", "td-btn-group-toggle"], [3, "ngClass", "name", "id", "disabled", "click", 4, "ngFor", "ngForOf"], [3, "ngClass", "name", "id", "disabled", "click"], ["id", "td-left-compare-container", "tdContainer", "", "cdkScrollable", "", 1, "td-table-container", "side-by-side"], [1, "td-table"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["scope", "row", 1, "fit-column", "line-number-col", 3, "ngClass"], [1, "fit-column", "prefix-col", 3, "ngClass"], ["class", "content-col", 3, "ngClass", 4, "ngIf"], [1, "content-col", 3, "ngClass"], [3, "innerHTML"], [3, "innerHTML", "ngClass", 4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "innerHTML", "ngClass"], ["id", "td-right-compare-container", "tdContainer", "", "cdkScrollable", "", 1, "td-table-container", "side-by-side"], [1, "td-table-container", "line-by-line"], ["scope", "row", 1, "fit-column", "line-number-col-left"], ["scope", "row", 1, "fit-column", "line-number-col"]], template: function NgxTextDiffComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵelement(0, "td-loader-spinner", 0);
        ɵngcc0.ɵɵtemplate(1, NgxTextDiffComponent_div_1_Template, 7, 9, "div", 1);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("active", ctx.loading);
        ɵngcc0.ɵɵadvance(1);
        ɵngcc0.ɵɵproperty("ngIf", !ctx.loading);
    } }, directives: function () { return [LoaderSpinnerComponent, ɵngcc2.NgIf, ɵngcc2.NgClass, ɵngcc2.NgStyle, ɵngcc3.CheckboxControlValueAccessor, ɵngcc3.NgControlStatus, ɵngcc3.NgModel, ɵngcc2.NgForOf, ContainerDirective, ɵngcc1.CdkScrollable]; }, pipes: function () { return [FormatLinePipe]; }, styles: [".td-wrapper[_ngcontent-%COMP%]{background-color:#fff;color:#444;display:grid;grid-row-gap:10px;grid-template-columns:repeat(2,[col] 50%);grid-template-rows:repeat(2,[row] auto);width:100%}.td-toolbar-show-diff[_ngcontent-%COMP%]{grid-column:1;grid-row:1}.td-toolbar-select-format[_ngcontent-%COMP%]{grid-column:2;grid-row:1;margin-left:auto}.td-table-container[_ngcontent-%COMP%]{grid-column:1/2;grid-row:2;max-width:100%;overflow-x:auto;width:100%}.td-table-wrapper[_ngcontent-%COMP%]{display:flex;width:200%}.td-table[_ngcontent-%COMP%]{border:1px solid #a9a9a9;max-height:50vh;max-width:100%;width:100%}.fit-column[_ngcontent-%COMP%]{white-space:nowrap;width:1px}.line-number-col[_ngcontent-%COMP%]{border-right:1px solid #ddd;left:0;position:relative;position:sticky;top:auto}.line-number-col[_ngcontent-%COMP%], .line-number-col-left[_ngcontent-%COMP%]{background-color:#f7f7f7;color:#999;font-size:87.5%;padding-left:10px;padding-right:10px;text-align:right}.insert-row[_ngcontent-%COMP%], .insert-row[_ngcontent-%COMP%] > .line-number-col[_ngcontent-%COMP%]{background-color:#dfd;border-color:#b4e2b4}.delete-row[_ngcontent-%COMP%], .delete-row[_ngcontent-%COMP%] > .line-number-col[_ngcontent-%COMP%]{background-color:#fee8e9;border-color:#e9aeae}.empty-row[_ngcontent-%COMP%]{background-color:#f7f7f7;height:24px}.td-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{border-top:0;max-width:50%;padding-bottom:0;padding-top:0;white-space:nowrap}pre[_ngcontent-%COMP%]{margin-bottom:0}td.content-col[_ngcontent-%COMP%]{line-height:24px;margin:0;padding:0}td.prefix-col[_ngcontent-%COMP%]{line-height:24px;padding-left:10px;padding-right:10px}.td-btn-group[_ngcontent-%COMP%]{border-radius:4px}.td-btn-group[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]{background-color:rgba(23,162,184,.7);border:1px solid #17a2b8;color:#fff;cursor:pointer;float:left}.td-btn-group[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:not(:last-child){border-right:none}.td-btn-group[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:first-child{-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px;-webkit-border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-bottom-left-radius:4px;border-top-left-radius:4px}.td-btn-group[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:last-child{-moz-border-radius-bottomright:4px;-moz-border-radius-topright:4px;-webkit-border-bottom-right-radius:4px;-webkit-border-top-right-radius:4px;border-bottom-right-radius:4px;border-top-right-radius:4px}.td-btn-group[_ngcontent-%COMP%]:after{clear:both;content:\"\";display:table}.td-btn-group[_ngcontent-%COMP%]   button.active[_ngcontent-%COMP%], .td-btn-group[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover{background-color:#17a2b8}.td-checkbox-container[_ngcontent-%COMP%]{-moz-user-select:none;-webkit-user-select:none;cursor:pointer;display:block;font-size:16px;line-height:28px;margin-bottom:0;padding-left:21px;position:relative;user-select:none}.td-checkbox-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]{cursor:pointer;height:0;opacity:0;position:absolute;width:0}.checkmark[_ngcontent-%COMP%]{background-color:#eee;height:16px;left:0;position:absolute;top:7px;width:16px}.td-checkbox-container[_ngcontent-%COMP%]:hover   input[_ngcontent-%COMP%] ~ .checkmark[_ngcontent-%COMP%]{background-color:#ccc}.td-checkbox-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:checked ~ .checkmark[_ngcontent-%COMP%]{background-color:#17a2b8}.checkmark[_ngcontent-%COMP%]:after{content:\"\";display:none;position:absolute}.td-checkbox-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:checked ~ .checkmark[_ngcontent-%COMP%]:after{display:block}.td-checkbox-container[_ngcontent-%COMP%]   .checkmark[_ngcontent-%COMP%]:after{border:solid #fff;border-width:0 3px 3px 0;height:10px;left:5px;top:3px;transform:rotate(45deg);width:5px}.insert-row[_ngcontent-%COMP%] > .highlight[_ngcontent-%COMP%]{background-color:#acf2bd!important}.delete-row[_ngcontent-%COMP%] > .highlight[_ngcontent-%COMP%]{background-color:#fdb8c0!important}"] });
NgxTextDiffComponent.ctorParameters = () => [
    { type: ScrollDispatcher },
    { type: NgxTextDiffService },
    { type: ChangeDetectorRef }
];
NgxTextDiffComponent.propDecorators = {
    containers: [{ type: ViewChildren, args: [ContainerDirective,] }],
    format: [{ type: Input }],
    left: [{ type: Input }],
    right: [{ type: Input }],
    diffContent: [{ type: Input }],
    loading: [{ type: Input }],
    showToolbar: [{ type: Input }],
    showBtnToolbar: [{ type: Input }],
    hideMatchingLines: [{ type: Input }],
    outerContainerClass: [{ type: Input }],
    outerContainerStyle: [{ type: Input }],
    toolbarClass: [{ type: Input }],
    toolbarStyle: [{ type: Input }],
    compareRowsClass: [{ type: Input }],
    compareRowsStyle: [{ type: Input }],
    synchronizeScrolling: [{ type: Input }],
    compareResults: [{ type: Output }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(NgxTextDiffComponent, [{
        type: Component,
        args: [{
                selector: 'td-ngx-text-diff',
                template: "<td-loader-spinner [active]=\"loading\"></td-loader-spinner>\n<div class=\"td-wrapper\" [ngClass]=\"outerContainerClass\" [ngStyle]=\"outerContainerStyle\" *ngIf=\"!loading\">\n\n  <div [ngClass]=\"toolbarClass\" [ngStyle]=\"toolbarStyle\" *ngIf=\"showToolbar\">\n    <div class=\"td-toolbar-show-diff\">\n      <label class=\"td-checkbox-container\">\n        Only Show Lines with Differences ({{ diffsCount }})\n        <input type=\"checkbox\" id=\"showDiffs\" [ngModel]=\"hideMatchingLines\" (ngModelChange)=\"hideMatchingLinesChanged($event)\" />\n        <span class=\"checkmark\"></span>\n      </label>\n    </div>\n  </div>\n\n  <div class=\"td-toolbar-select-format\" *ngIf=\"showToolbar && showBtnToolbar\">\n    <div class=\"td-btn-group td-btn-group-toggle\" data-toggle=\"buttons\">\n      <button\n        *ngFor=\"let option of formatOptions\"\n        [ngClass]=\"{ active: format === option.value, disabled: !!option.disabled }\"\n        [name]=\"option.name\"\n        [id]=\"option.id\"\n        [disabled]=\"!!option.disabled\"\n        (click)=\"setDiffTableFormat(option.value)\"\n      >\n        {{ option.label }}\n      </button>\n    </div>\n  </div>\n\n  <div class=\"td-table-wrapper\" [ngClass]=\"compareRowsClass\" [ngStyle]=\"compareRowsStyle\">\n    <!-- Right side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-left-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              {{ row.leftContent?.lineNumber !== -1 ? row.leftContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              <span>{{ row.leftContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Left side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-right-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              {{ row.rightContent?.lineNumber !== -1 ? row.rightContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              <span>{{ row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.rightContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Line By Line - combined table -->\n    <div class=\"td-table-container line-by-line\" *ngIf=\"format === 'LineByLine'\">\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRowsLineByLine; trackBy: trackTableRows\">\n            <td scope=\"row\" class=\"fit-column line-number-col-left\">{{ row.leftContent?.lineNumber }}</td>\n            <td scope=\"row\" class=\"fit-column line-number-col\">{{ row.rightContent?.lineNumber }}</td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n            >\n              <span>{{ row.leftContent?.prefix || row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.leftContent && row.leftContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.rightContent && row.rightContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n</div>\n",
                styles: [".td-wrapper{background-color:#fff;color:#444;display:grid;grid-row-gap:10px;grid-template-columns:repeat(2,[col] 50%);grid-template-rows:repeat(2,[row] auto);width:100%}.td-toolbar-show-diff{grid-column:1;grid-row:1}.td-toolbar-select-format{grid-column:2;grid-row:1;margin-left:auto}.td-table-container{grid-column:1/2;grid-row:2;max-width:100%;overflow-x:auto;width:100%}.td-table-wrapper{display:flex;width:200%}.td-table{border:1px solid #a9a9a9;max-height:50vh;max-width:100%;width:100%}.fit-column{white-space:nowrap;width:1px}.line-number-col{border-right:1px solid #ddd;left:0;position:relative;position:sticky;top:auto}.line-number-col,.line-number-col-left{background-color:#f7f7f7;color:#999;font-size:87.5%;padding-left:10px;padding-right:10px;text-align:right}.insert-row,.insert-row>.line-number-col{background-color:#dfd;border-color:#b4e2b4}.delete-row,.delete-row>.line-number-col{background-color:#fee8e9;border-color:#e9aeae}.empty-row{background-color:#f7f7f7;height:24px}.td-table td{border-top:0;max-width:50%;padding-bottom:0;padding-top:0;white-space:nowrap}pre{margin-bottom:0}td.content-col{line-height:24px;margin:0;padding:0}td.prefix-col{line-height:24px;padding-left:10px;padding-right:10px}.td-btn-group{border-radius:4px}.td-btn-group button{background-color:rgba(23,162,184,.7);border:1px solid #17a2b8;color:#fff;cursor:pointer;float:left}.td-btn-group button:not(:last-child){border-right:none}.td-btn-group button:first-child{-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px;-webkit-border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-bottom-left-radius:4px;border-top-left-radius:4px}.td-btn-group button:last-child{-moz-border-radius-bottomright:4px;-moz-border-radius-topright:4px;-webkit-border-bottom-right-radius:4px;-webkit-border-top-right-radius:4px;border-bottom-right-radius:4px;border-top-right-radius:4px}.td-btn-group:after{clear:both;content:\"\";display:table}.td-btn-group button.active,.td-btn-group button:hover{background-color:#17a2b8}.td-checkbox-container{-moz-user-select:none;-webkit-user-select:none;cursor:pointer;display:block;font-size:16px;line-height:28px;margin-bottom:0;padding-left:21px;position:relative;user-select:none}.td-checkbox-container input{cursor:pointer;height:0;opacity:0;position:absolute;width:0}.checkmark{background-color:#eee;height:16px;left:0;position:absolute;top:7px;width:16px}.td-checkbox-container:hover input~.checkmark{background-color:#ccc}.td-checkbox-container input:checked~.checkmark{background-color:#17a2b8}.checkmark:after{content:\"\";display:none;position:absolute}.td-checkbox-container input:checked~.checkmark:after{display:block}.td-checkbox-container .checkmark:after{border:solid #fff;border-width:0 3px 3px 0;height:10px;left:5px;top:3px;transform:rotate(45deg);width:5px}.insert-row>.highlight{background-color:#acf2bd!important}.delete-row>.highlight{background-color:#fdb8c0!important}"]
            }]
    }], function () { return [{ type: ɵngcc1.ScrollDispatcher }, { type: NgxTextDiffService }, { type: ɵngcc0.ChangeDetectorRef }]; }, { format: [{
            type: Input
        }], left: [{
            type: Input
        }], right: [{
            type: Input
        }], loading: [{
            type: Input
        }], showToolbar: [{
            type: Input
        }], showBtnToolbar: [{
            type: Input
        }], synchronizeScrolling: [{
            type: Input
        }], compareResults: [{
            type: Output
        }], hideMatchingLines: [{
            type: Input
        }], containers: [{
            type: ViewChildren,
            args: [ContainerDirective]
        }], diffContent: [{
            type: Input
        }], outerContainerClass: [{
            type: Input
        }], outerContainerStyle: [{
            type: Input
        }], toolbarClass: [{
            type: Input
        }], toolbarStyle: [{
            type: Input
        }], compareRowsClass: [{
            type: Input
        }], compareRowsStyle: [{
            type: Input
        }] }); })();

class LoaderSpinnerComponent {
    constructor() {
        this.active = false;
    }
    ngOnInit() { }
}
LoaderSpinnerComponent.ɵfac = function LoaderSpinnerComponent_Factory(t) { return new (t || LoaderSpinnerComponent)(); };
LoaderSpinnerComponent.ɵcmp = ɵngcc0.ɵɵdefineComponent({ type: LoaderSpinnerComponent, selectors: [["td-loader-spinner"]], inputs: { active: "active" }, decls: 1, vars: 1, consts: [["class", "td-loading-roller", 4, "ngIf"], [1, "td-loading-roller"]], template: function LoaderSpinnerComponent_Template(rf, ctx) { if (rf & 1) {
        ɵngcc0.ɵɵtemplate(0, LoaderSpinnerComponent_div_0_Template, 9, 0, "div", 0);
    } if (rf & 2) {
        ɵngcc0.ɵɵproperty("ngIf", ctx.active);
    } }, directives: [ɵngcc2.NgIf], styles: [".td-loading-roller[_ngcontent-%COMP%]{display:inline-block;height:64px;position:relative;width:64px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]{-webkit-animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;transform-origin:32px 32px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:after{background:#000;border-radius:50%;content:\" \";display:block;height:6px;margin:-3px 0 0 -3px;position:absolute;width:6px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:first-child{-webkit-animation-delay:-36ms;animation-delay:-36ms}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:first-child:after{left:50px;top:50px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(2){-webkit-animation-delay:-72ms;animation-delay:-72ms}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(2):after{left:45px;top:54px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(3){-webkit-animation-delay:-.108s;animation-delay:-.108s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(3):after{left:39px;top:57px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(4){-webkit-animation-delay:-.144s;animation-delay:-.144s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(4):after{left:32px;top:58px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(5){-webkit-animation-delay:-.18s;animation-delay:-.18s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(5):after{left:25px;top:57px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(6){-webkit-animation-delay:-.216s;animation-delay:-.216s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(6):after{left:19px;top:54px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(7){-webkit-animation-delay:-.252s;animation-delay:-.252s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(7):after{left:14px;top:50px}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(8){-webkit-animation-delay:-.288s;animation-delay:-.288s}.td-loading-roller[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]:nth-child(8):after{left:10px;top:45px}@-webkit-keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}"] });
LoaderSpinnerComponent.ctorParameters = () => [];
LoaderSpinnerComponent.propDecorators = {
    active: [{ type: Input }]
};
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(LoaderSpinnerComponent, [{
        type: Component,
        args: [{
                selector: 'td-loader-spinner',
                template: "<div class=\"td-loading-roller\" *ngIf=\"active\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n</div>\n",
                styles: [".td-loading-roller{display:inline-block;height:64px;position:relative;width:64px}.td-loading-roller div{-webkit-animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;transform-origin:32px 32px}.td-loading-roller div:after{background:#000;border-radius:50%;content:\" \";display:block;height:6px;margin:-3px 0 0 -3px;position:absolute;width:6px}.td-loading-roller div:first-child{-webkit-animation-delay:-36ms;animation-delay:-36ms}.td-loading-roller div:first-child:after{left:50px;top:50px}.td-loading-roller div:nth-child(2){-webkit-animation-delay:-72ms;animation-delay:-72ms}.td-loading-roller div:nth-child(2):after{left:45px;top:54px}.td-loading-roller div:nth-child(3){-webkit-animation-delay:-.108s;animation-delay:-.108s}.td-loading-roller div:nth-child(3):after{left:39px;top:57px}.td-loading-roller div:nth-child(4){-webkit-animation-delay:-.144s;animation-delay:-.144s}.td-loading-roller div:nth-child(4):after{left:32px;top:58px}.td-loading-roller div:nth-child(5){-webkit-animation-delay:-.18s;animation-delay:-.18s}.td-loading-roller div:nth-child(5):after{left:25px;top:57px}.td-loading-roller div:nth-child(6){-webkit-animation-delay:-.216s;animation-delay:-.216s}.td-loading-roller div:nth-child(6):after{left:19px;top:54px}.td-loading-roller div:nth-child(7){-webkit-animation-delay:-.252s;animation-delay:-.252s}.td-loading-roller div:nth-child(7):after{left:14px;top:50px}.td-loading-roller div:nth-child(8){-webkit-animation-delay:-.288s;animation-delay:-.288s}.td-loading-roller div:nth-child(8):after{left:10px;top:45px}@-webkit-keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}"]
            }]
    }], function () { return []; }, { active: [{
            type: Input
        }] }); })();

class FormatLinePipe {
    transform(line, diffs) {
        if (!line) {
            return ' ';
        }
        if (!!diffs && diffs.length > 0) {
            /*diffs.forEach(diff => {
              line = line.replace(diff, `<span class="highli">${diff}</span>`);
            });*/
        }
        return line
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/ /g, '&nbsp;');
    }
}
FormatLinePipe.ɵfac = function FormatLinePipe_Factory(t) { return new (t || FormatLinePipe)(); };
FormatLinePipe.ɵpipe = ɵngcc0.ɵɵdefinePipe({ name: "formatLine", type: FormatLinePipe, pure: true });
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(FormatLinePipe, [{
        type: Pipe,
        args: [{
                name: 'formatLine'
            }]
    }], null, null); })();

class NgxTextDiffModule {
}
NgxTextDiffModule.ɵmod = ɵngcc0.ɵɵdefineNgModule({ type: NgxTextDiffModule });
NgxTextDiffModule.ɵinj = ɵngcc0.ɵɵdefineInjector({ factory: function NgxTextDiffModule_Factory(t) { return new (t || NgxTextDiffModule)(); }, imports: [[CommonModule, FormsModule, ScrollingModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵngcc0.ɵɵsetNgModuleScope(NgxTextDiffModule, { declarations: function () { return [NgxTextDiffComponent, LoaderSpinnerComponent, FormatLinePipe, ContainerDirective]; }, imports: function () { return [CommonModule, FormsModule, ScrollingModule]; }, exports: function () { return [NgxTextDiffComponent]; } }); })();
/*@__PURE__*/ (function () { ɵngcc0.ɵsetClassMetadata(NgxTextDiffModule, [{
        type: NgModule,
        args: [{
                imports: [CommonModule, FormsModule, ScrollingModule],
                declarations: [NgxTextDiffComponent, LoaderSpinnerComponent, FormatLinePipe, ContainerDirective],
                exports: [NgxTextDiffComponent]
            }]
    }], null, null); })();

/*
 * Public API Surface of ngx-text-diff
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxTextDiffComponent, NgxTextDiffModule, NgxTextDiffService, ContainerDirective as ɵa, LoaderSpinnerComponent as ɵb, FormatLinePipe as ɵc };

//# sourceMappingURL=ngx-text-diff.js.map