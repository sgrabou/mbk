export * from './lib/ngx-text-diff.service';
export * from './lib/ngx-text-diff.component';
export * from './lib/ngx-text-diff.module';
