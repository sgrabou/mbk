import { OnInit } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class LoaderSpinnerComponent implements OnInit {
    active: boolean;
    constructor();
    ngOnInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<LoaderSpinnerComponent, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<LoaderSpinnerComponent, "td-loader-spinner", never, { "active": "active"; }, {}, never, never>;
}

//# sourceMappingURL=loader-spinner.component.d.ts.map