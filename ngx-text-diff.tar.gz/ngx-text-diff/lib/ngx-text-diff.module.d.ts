import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './ngx-text-diff.component';
import * as ɵngcc2 from './loader-spinner/loader-spinner.component';
import * as ɵngcc3 from './format-line.pipe';
import * as ɵngcc4 from './ngx-text-diff-container.directive';
import * as ɵngcc5 from '@angular/common';
import * as ɵngcc6 from '@angular/forms';
import * as ɵngcc7 from '@angular/cdk/scrolling';
export declare class NgxTextDiffModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgxTextDiffModule, [typeof ɵngcc1.NgxTextDiffComponent, typeof ɵngcc2.LoaderSpinnerComponent, typeof ɵngcc3.FormatLinePipe, typeof ɵngcc4.ContainerDirective], [typeof ɵngcc5.CommonModule, typeof ɵngcc6.FormsModule, typeof ɵngcc7.ScrollingModule], [typeof ɵngcc1.NgxTextDiffComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgxTextDiffModule>;
}

//# sourceMappingURL=ngx-text-diff.module.d.ts.map