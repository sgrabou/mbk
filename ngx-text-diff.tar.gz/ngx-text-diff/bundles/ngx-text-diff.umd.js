(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('diff-match-patch'), require('@angular/cdk/scrolling'), require('@angular/common'), require('@angular/forms')) :
    typeof define === 'function' && define.amd ? define('ngx-text-diff', ['exports', '@angular/core', 'diff-match-patch', '@angular/cdk/scrolling', '@angular/common', '@angular/forms'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['ngx-text-diff'] = {}, global.ng.core, global.diffMatchPatch, global.ng.cdk.scrolling, global.ng.common, global.ng.forms));
}(this, (function (exports, i0, diffMatchPatch, scrolling, common, forms) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () {
                            return e[k];
                        }
                    });
                }
            });
        }
        n['default'] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from) {
        for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
            to[j] = from[i];
        return to;
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }

    var isNil = function (val) { return val === undefined || val === null; };
    var isEmpty = function (val) { return val == null || !(Object.keys(val) || val).length || (Object.keys(val) || val).length === 0; };

    var NgxTextDiffFormatterService = /** @class */ (function () {
        function NgxTextDiffFormatterService(diffParser) {
            this.diffParser = diffParser;
        }
        NgxTextDiffFormatterService.prototype.initializeCounters = function () {
            this.leftCounter = 1;
            this.rightCounter = 1;
        };
        NgxTextDiffFormatterService.prototype.formatOutput = function (diffs) {
            this.initializeCounters();
            var result = [];
            for (var index = 0; index < diffs.length; index++) {
                var _a = __read(diffs[index], 2), diffType = _a[0], diffValue = _a[1];
                var _b = __read(diffs.length - 1 > index ? diffs[index + 1] : [], 2), nextType = _b[0], nextValue = _b[1];
                switch (diffType) {
                    case diffMatchPatch.DIFF_EQUAL:
                        this.createEqualRowResults(result, diffValue);
                        break;
                    case diffMatchPatch.DIFF_DELETE:
                        if (nextType === diffMatchPatch.DIFF_INSERT) {
                            this.createMergeRowResults(result, diffValue, nextValue);
                            index += 1;
                        }
                        else {
                            this.createDeleteRowResults(result, diffValue);
                        }
                        break;
                    case diffMatchPatch.DIFF_INSERT:
                        if (nextType === diffMatchPatch.DIFF_DELETE) {
                            this.createMergeRowResults(result, diffValue, nextValue);
                            index += 1;
                        }
                        else {
                            this.createInsertRowResults(result, diffValue);
                        }
                        break;
                }
            }
            return result;
        };
        NgxTextDiffFormatterService.prototype.createEqualRowResults = function (result, diffValue) {
            var _this = this;
            var lines = this.getLines(diffValue);
            lines.forEach(function (line) {
                result.push({
                    leftContent: {
                        lineNumber: _this.leftCounter,
                        lineContent: line,
                        lineDiffs: [],
                        prefix: '',
                    },
                    rightContent: {
                        lineNumber: _this.rightCounter,
                        lineContent: line,
                        lineDiffs: [],
                        prefix: '',
                    },
                    belongTo: 'both',
                    hasDiffs: false,
                    numDiffs: 0,
                });
                _this.leftCounter = _this.leftCounter + 1;
                _this.rightCounter = _this.rightCounter + 1;
            });
        };
        NgxTextDiffFormatterService.prototype.createDeleteRowResults = function (result, diffValue) {
            var _this = this;
            var lines = this.getLines(diffValue);
            lines.forEach(function (line) {
                result.push({
                    leftContent: {
                        lineNumber: _this.leftCounter,
                        lineContent: line,
                        lineDiffs: [{ content: line, isDiff: true }],
                        prefix: '-',
                    },
                    rightContent: null,
                    hasDiffs: true,
                    belongTo: 'left',
                    numDiffs: 1,
                });
                _this.leftCounter = _this.leftCounter + 1;
            });
        };
        NgxTextDiffFormatterService.prototype.createInsertRowResults = function (result, diffValue) {
            var _this = this;
            var lines = this.getLines(diffValue);
            lines.forEach(function (line) {
                result.push({
                    leftContent: null,
                    rightContent: {
                        lineNumber: _this.rightCounter,
                        lineContent: line,
                        lineDiffs: [{ content: line, isDiff: true }],
                        prefix: '+',
                    },
                    hasDiffs: true,
                    belongTo: 'right',
                    numDiffs: 1,
                });
                _this.rightCounter = _this.rightCounter + 1;
            });
        };
        NgxTextDiffFormatterService.prototype.createMergeRowResults = function (result, oldValue, newValue) {
            var beforeLines = this.getLines(oldValue);
            var afterLines = this.getLines(newValue);
            var longestLength = Math.max(beforeLines.length, afterLines.length);
            for (var index = 0; index < longestLength; index++) {
                if (beforeLines[index] != null && afterLines[index] != null) {
                    this.mergeResults(result, beforeLines[index], afterLines[index]);
                }
                else if (beforeLines[index] != null) {
                    this.createDeleteRowResults(result, beforeLines[index]);
                }
                else if (afterLines[index] != null) {
                    this.createInsertRowResults(result, afterLines[index]);
                }
            }
        };
        NgxTextDiffFormatterService.prototype.getLines = function (diffValue) {
            return diffValue
                .split('\n')
                .filter(function (value, index, array) { return index !== array.length - 1 || !isEmpty(value); });
        };
        NgxTextDiffFormatterService.prototype.mergeResults = function (result, leftLine, rightLine) {
            var entry = {
                leftContent: {
                    lineNumber: this.leftCounter,
                    lineContent: leftLine,
                    lineDiffs: this.getDiffParts(leftLine, rightLine),
                    prefix: '-',
                },
                rightContent: null,
                hasDiffs: true,
                belongTo: 'both',
                numDiffs: 1,
            };
            entry.rightContent = {
                lineNumber: this.rightCounter,
                lineContent: rightLine,
                lineDiffs: this.getDiffParts(rightLine, leftLine),
                prefix: '+',
            };
            entry.numDiffs = this.countDiffs(entry);
            this.leftCounter = this.leftCounter + 1;
            this.rightCounter = this.rightCounter + 1;
            result.push(entry);
        };
        NgxTextDiffFormatterService.prototype.getDiffParts = function (value, compareValue) {
            var diffs = this.diffParser.diff_main(value, compareValue);
            return diffs.filter(function (_a) {
                var _b = __read(_a, 1), type = _b[0];
                return type !== diffMatchPatch.DIFF_INSERT;
            }).map(function (_a) {
                var _b = __read(_a, 2), type = _b[0], content = _b[1];
                return ({ content: content, isDiff: type !== diffMatchPatch.DIFF_EQUAL });
            });
        };
        NgxTextDiffFormatterService.prototype.countDiffs = function (result) {
            var diffCount = 0;
            if (result.leftContent) {
                diffCount += result.leftContent.lineDiffs.filter(function (diff) { return diff.isDiff; }).length;
            }
            if (result.rightContent) {
                diffCount += result.rightContent.lineDiffs.filter(function (diff) { return diff.isDiff; }).length;
            }
            return diffCount;
        };
        return NgxTextDiffFormatterService;
    }());

    var NgxTextDiffService = /** @class */ (function () {
        function NgxTextDiffService() {
            this.initParser();
        }
        NgxTextDiffService.prototype.initParser = function () {
            this.diffParser = new diffMatchPatch.diff_match_patch();
        };
        NgxTextDiffService.prototype.getDiffsByLines = function (left, right) {
            var _this = this;
            return new Promise(function (resolve, reject) {
                var a = _this.diffParser.diff_linesToChars_(left, right);
                var lineText1 = a.chars1;
                var lineText2 = a.chars2;
                var linesArray = a.lineArray;
                var diffs = _this.diffParser.diff_main(lineText1, lineText2, true);
                _this.diffParser.diff_charsToLines_(diffs, linesArray);
                var formatter = new NgxTextDiffFormatterService(_this.diffParser);
                var rows = formatter.formatOutput(diffs);
                if (!rows) {
                    reject('Error');
                }
                resolve(rows);
            });
        };
        return NgxTextDiffService;
    }());
    NgxTextDiffService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function NgxTextDiffService_Factory() { return new NgxTextDiffService(); }, token: NgxTextDiffService, providedIn: "root" });
    NgxTextDiffService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];
    NgxTextDiffService.ctorParameters = function () { return []; };

    var ContainerDirective = /** @class */ (function () {
        function ContainerDirective(_el) {
            this._el = _el;
            this.element = _el.nativeElement;
        }
        return ContainerDirective;
    }());
    ContainerDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[tdContainer]',
                },] }
    ];
    ContainerDirective.ctorParameters = function () { return [
        { type: i0.ElementRef }
    ]; };
    ContainerDirective.propDecorators = {
        id: [{ type: i0.Input }]
    };

    var NgxTextDiffComponent = /** @class */ (function () {
        function NgxTextDiffComponent(scrollService, diff, cd) {
            this.scrollService = scrollService;
            this.diff = diff;
            this.cd = cd;
            this._hideMatchingLines = false;
            this.format = 'SideBySide';
            this.left = '';
            this.right = '';
            this.loading = false;
            this.showToolbar = true;
            this.showBtnToolbar = true;
            this.synchronizeScrolling = true;
            this.compareResults = new i0.EventEmitter();
            this.subscriptions = [];
            this.tableRows = [];
            this.filteredTableRows = [];
            this.tableRowsLineByLine = [];
            this.filteredTableRowsLineByLine = [];
            this.diffsCount = 0;
            this.formatOptions = [
                {
                    id: 'side-by-side',
                    name: 'side-by-side',
                    label: 'Side by Side',
                    value: 'SideBySide',
                    icon: 'la-code',
                },
                {
                    id: 'line-by-line',
                    name: 'line-by-line',
                    label: 'Line by Line',
                    value: 'LineByLine',
                    icon: 'la-file-text',
                },
            ];
        }
        Object.defineProperty(NgxTextDiffComponent.prototype, "hideMatchingLines", {
            get: function () {
                return this._hideMatchingLines;
            },
            set: function (hide) {
                this.hideMatchingLinesChanged(hide);
            },
            enumerable: false,
            configurable: true
        });
        NgxTextDiffComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.loading = true;
            if (this.diffContent) {
                this.subscriptions.push(this.diffContent.subscribe(function (content) {
                    _this.loading = true;
                    _this.left = content.leftContent;
                    _this.right = content.rightContent;
                    _this.renderDiffs()
                        .then(function () {
                        _this.cd.detectChanges();
                        _this.loading = false;
                    })
                        .catch(function () { return (_this.loading = false); });
                }));
            }
            this.renderDiffs()
                .then(function () { return (_this.loading = false); })
                .catch(function (e) { return (_this.loading = false); });
        };
        NgxTextDiffComponent.prototype.ngAfterViewInit = function () {
            this.initScrollListener();
        };
        NgxTextDiffComponent.prototype.ngOnDestroy = function () {
            if (this.subscriptions) {
                this.subscriptions.forEach(function (subscription) { return subscription.unsubscribe(); });
            }
        };
        NgxTextDiffComponent.prototype.hideMatchingLinesChanged = function (value) {
            this._hideMatchingLines = value;
            if (this.hideMatchingLines) {
                this.filteredTableRows = this.tableRows.filter(function (row) { return (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'); });
                this.filteredTableRowsLineByLine = this.tableRowsLineByLine.filter(function (row) { return (row.leftContent && row.leftContent.prefix === '-') || (row.rightContent && row.rightContent.prefix === '+'); });
            }
            else {
                this.filteredTableRows = this.tableRows;
                this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
            }
        };
        NgxTextDiffComponent.prototype.setDiffTableFormat = function (format) {
            this.format = format;
        };
        NgxTextDiffComponent.prototype.renderDiffs = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _a, e_1;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _b.trys.push([0, 2, , 3]);
                            this.diffsCount = 0;
                            _a = this;
                            return [4 /*yield*/, this.diff.getDiffsByLines(this.left, this.right)];
                        case 1:
                            _a.tableRows = _b.sent();
                            this.tableRowsLineByLine = this.tableRows.reduce(function (tableLineByLine, row) {
                                if (!tableLineByLine) {
                                    tableLineByLine = [];
                                }
                                if (row.hasDiffs) {
                                    if (row.leftContent) {
                                        tableLineByLine.push({
                                            leftContent: row.leftContent,
                                            rightContent: null,
                                            belongTo: row.belongTo,
                                            hasDiffs: true,
                                            numDiffs: row.numDiffs,
                                        });
                                    }
                                    if (row.rightContent) {
                                        tableLineByLine.push({
                                            leftContent: null,
                                            rightContent: row.rightContent,
                                            belongTo: row.belongTo,
                                            hasDiffs: true,
                                            numDiffs: row.numDiffs,
                                        });
                                    }
                                }
                                else {
                                    tableLineByLine.push(row);
                                }
                                return tableLineByLine;
                            }, []);
                            this.diffsCount = this.tableRows.filter(function (row) { return row.hasDiffs; }).length;
                            this.filteredTableRows = this.tableRows;
                            this.filteredTableRowsLineByLine = this.tableRowsLineByLine;
                            this.emitCompareResultsEvent();
                            return [3 /*break*/, 3];
                        case 2:
                            e_1 = _b.sent();
                            throw e_1;
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        NgxTextDiffComponent.prototype.emitCompareResultsEvent = function () {
            var diffResults = {
                hasDiff: this.diffsCount > 0,
                diffsCount: this.diffsCount,
                rowsWithDiff: this.tableRows
                    .filter(function (row) { return row.hasDiffs; })
                    .map(function (row) { return ({
                    leftLineNumber: row.leftContent ? row.leftContent.lineNumber : null,
                    rightLineNumber: row.rightContent ? row.rightContent.lineNumber : null,
                    numDiffs: row.numDiffs,
                }); }),
            };
            this.compareResults.next(diffResults);
        };
        NgxTextDiffComponent.prototype.trackTableRows = function (index, row) {
            return row && row.leftContent ? row.leftContent.lineContent : row && row.rightContent ? row.rightContent.lineContent : undefined;
        };
        NgxTextDiffComponent.prototype.trackDiffs = function (index, diff) {
            return diff && diff.content ? diff.content : undefined;
        };
        NgxTextDiffComponent.prototype.initScrollListener = function () {
            var _this = this;
            this.subscriptions.push(this.scrollService.scrolled().subscribe(function (scrollableEv) {
                if (scrollableEv && _this.synchronizeScrolling) {
                    var scrollableId_1 = scrollableEv.getElementRef().nativeElement.id;
                    var nonScrolledContainer = _this.containers.find(function (container) { return container.id !== scrollableId_1; });
                    if (nonScrolledContainer) {
                        nonScrolledContainer.element.scrollTo({
                            top: scrollableEv.measureScrollOffset('top'),
                            left: scrollableEv.measureScrollOffset('left'),
                        });
                    }
                }
            }));
        };
        return NgxTextDiffComponent;
    }());
    NgxTextDiffComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'td-ngx-text-diff',
                    template: "<td-loader-spinner [active]=\"loading\"></td-loader-spinner>\n<div class=\"td-wrapper\" [ngClass]=\"outerContainerClass\" [ngStyle]=\"outerContainerStyle\" *ngIf=\"!loading\">\n\n  <div [ngClass]=\"toolbarClass\" [ngStyle]=\"toolbarStyle\" *ngIf=\"showToolbar\">\n    <div class=\"td-toolbar-show-diff\">\n      <label class=\"td-checkbox-container\">\n        Only Show Lines with Differences ({{ diffsCount }})\n        <input type=\"checkbox\" id=\"showDiffs\" [ngModel]=\"hideMatchingLines\" (ngModelChange)=\"hideMatchingLinesChanged($event)\" />\n        <span class=\"checkmark\"></span>\n      </label>\n    </div>\n  </div>\n\n  <div class=\"td-toolbar-select-format\" *ngIf=\"showToolbar && showBtnToolbar\">\n    <div class=\"td-btn-group td-btn-group-toggle\" data-toggle=\"buttons\">\n      <button\n        *ngFor=\"let option of formatOptions\"\n        [ngClass]=\"{ active: format === option.value, disabled: !!option.disabled }\"\n        [name]=\"option.name\"\n        [id]=\"option.id\"\n        [disabled]=\"!!option.disabled\"\n        (click)=\"setDiffTableFormat(option.value)\"\n      >\n        {{ option.label }}\n      </button>\n    </div>\n  </div>\n\n  <div class=\"td-table-wrapper\" [ngClass]=\"compareRowsClass\" [ngStyle]=\"compareRowsStyle\">\n    <!-- Right side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-left-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              {{ row.leftContent?.lineNumber !== -1 ? row.leftContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n            >\n              <span>{{ row.leftContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'empty-row': !row.leftContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Left side-by-side -->\n    <div class=\"td-table-container side-by-side\" *ngIf=\"format === 'SideBySide'\" id=\"td-right-compare-container\" tdContainer cdkScrollable>\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRows; trackBy: trackTableRows\">\n            <td\n              scope=\"row\"\n              class=\"fit-column line-number-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              {{ row.rightContent?.lineNumber !== -1 ? row.rightContent?.lineNumber : ' ' }}\n            </td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n            >\n              <span>{{ row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.rightContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'insert-row': row.rightContent?.prefix === '+', 'empty-row': !row.rightContent?.lineContent }\"\n              *ngIf=\"row.hasDiffs\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n    <!-- Line By Line - combined table -->\n    <div class=\"td-table-container line-by-line\" *ngIf=\"format === 'LineByLine'\">\n      <table class=\"td-table\">\n        <tbody>\n          <tr *ngFor=\"let row of filteredTableRowsLineByLine; trackBy: trackTableRows\">\n            <td scope=\"row\" class=\"fit-column line-number-col-left\">{{ row.leftContent?.lineNumber }}</td>\n            <td scope=\"row\" class=\"fit-column line-number-col\">{{ row.rightContent?.lineNumber }}</td>\n            <td\n              class=\"fit-column prefix-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n            >\n              <span>{{ row.leftContent?.prefix || row.rightContent?.prefix || ' ' }}</span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"!row.hasDiffs\"\n            >\n              <span [innerHTML]=\"row.leftContent?.lineContent | formatLine\"></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.leftContent && row.leftContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.leftContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n            <td\n              class=\"content-col\"\n              [ngClass]=\"{ 'delete-row': row.leftContent?.prefix === '-', 'insert-row': row.rightContent?.prefix === '+' }\"\n              *ngIf=\"row.hasDiffs && row.rightContent && row.rightContent?.lineDiffs.length !== 0\"\n            >\n              <span\n                [innerHTML]=\"diff.content | formatLine\"\n                [ngClass]=\"{ highlight: diff.isDiff }\"\n                *ngFor=\"let diff of row.rightContent?.lineDiffs; trackBy: trackDiffs\"\n              ></span>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n</div>\n",
                    styles: [".td-wrapper{background-color:#fff;color:#444;display:grid;grid-row-gap:10px;grid-template-columns:repeat(2,[col] 50%);grid-template-rows:repeat(2,[row] auto);width:100%}.td-toolbar-show-diff{grid-column:1;grid-row:1}.td-toolbar-select-format{grid-column:2;grid-row:1;margin-left:auto}.td-table-container{grid-column:1/2;grid-row:2;max-width:100%;overflow-x:auto;width:100%}.td-table-wrapper{display:flex;width:200%}.td-table{border:1px solid #a9a9a9;max-height:50vh;max-width:100%;width:100%}.fit-column{white-space:nowrap;width:1px}.line-number-col{border-right:1px solid #ddd;left:0;position:relative;position:sticky;top:auto}.line-number-col,.line-number-col-left{background-color:#f7f7f7;color:#999;font-size:87.5%;padding-left:10px;padding-right:10px;text-align:right}.insert-row,.insert-row>.line-number-col{background-color:#dfd;border-color:#b4e2b4}.delete-row,.delete-row>.line-number-col{background-color:#fee8e9;border-color:#e9aeae}.empty-row{background-color:#f7f7f7;height:24px}.td-table td{border-top:0;max-width:50%;padding-bottom:0;padding-top:0;white-space:nowrap}pre{margin-bottom:0}td.content-col{line-height:24px;margin:0;padding:0}td.prefix-col{line-height:24px;padding-left:10px;padding-right:10px}.td-btn-group{border-radius:4px}.td-btn-group button{background-color:rgba(23,162,184,.7);border:1px solid #17a2b8;color:#fff;cursor:pointer;float:left}.td-btn-group button:not(:last-child){border-right:none}.td-btn-group button:first-child{-moz-border-radius-bottomleft:4px;-moz-border-radius-topleft:4px;-webkit-border-bottom-left-radius:4px;-webkit-border-top-left-radius:4px;border-bottom-left-radius:4px;border-top-left-radius:4px}.td-btn-group button:last-child{-moz-border-radius-bottomright:4px;-moz-border-radius-topright:4px;-webkit-border-bottom-right-radius:4px;-webkit-border-top-right-radius:4px;border-bottom-right-radius:4px;border-top-right-radius:4px}.td-btn-group:after{clear:both;content:\"\";display:table}.td-btn-group button.active,.td-btn-group button:hover{background-color:#17a2b8}.td-checkbox-container{-moz-user-select:none;-webkit-user-select:none;cursor:pointer;display:block;font-size:16px;line-height:28px;margin-bottom:0;padding-left:21px;position:relative;user-select:none}.td-checkbox-container input{cursor:pointer;height:0;opacity:0;position:absolute;width:0}.checkmark{background-color:#eee;height:16px;left:0;position:absolute;top:7px;width:16px}.td-checkbox-container:hover input~.checkmark{background-color:#ccc}.td-checkbox-container input:checked~.checkmark{background-color:#17a2b8}.checkmark:after{content:\"\";display:none;position:absolute}.td-checkbox-container input:checked~.checkmark:after{display:block}.td-checkbox-container .checkmark:after{border:solid #fff;border-width:0 3px 3px 0;height:10px;left:5px;top:3px;transform:rotate(45deg);width:5px}.insert-row>.highlight{background-color:#acf2bd!important}.delete-row>.highlight{background-color:#fdb8c0!important}"]
                },] }
    ];
    NgxTextDiffComponent.ctorParameters = function () { return [
        { type: scrolling.ScrollDispatcher },
        { type: NgxTextDiffService },
        { type: i0.ChangeDetectorRef }
    ]; };
    NgxTextDiffComponent.propDecorators = {
        containers: [{ type: i0.ViewChildren, args: [ContainerDirective,] }],
        format: [{ type: i0.Input }],
        left: [{ type: i0.Input }],
        right: [{ type: i0.Input }],
        diffContent: [{ type: i0.Input }],
        loading: [{ type: i0.Input }],
        showToolbar: [{ type: i0.Input }],
        showBtnToolbar: [{ type: i0.Input }],
        hideMatchingLines: [{ type: i0.Input }],
        outerContainerClass: [{ type: i0.Input }],
        outerContainerStyle: [{ type: i0.Input }],
        toolbarClass: [{ type: i0.Input }],
        toolbarStyle: [{ type: i0.Input }],
        compareRowsClass: [{ type: i0.Input }],
        compareRowsStyle: [{ type: i0.Input }],
        synchronizeScrolling: [{ type: i0.Input }],
        compareResults: [{ type: i0.Output }]
    };

    var LoaderSpinnerComponent = /** @class */ (function () {
        function LoaderSpinnerComponent() {
            this.active = false;
        }
        LoaderSpinnerComponent.prototype.ngOnInit = function () { };
        return LoaderSpinnerComponent;
    }());
    LoaderSpinnerComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'td-loader-spinner',
                    template: "<div class=\"td-loading-roller\" *ngIf=\"active\">\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n  <div></div>\n</div>\n",
                    styles: [".td-loading-roller{display:inline-block;height:64px;position:relative;width:64px}.td-loading-roller div{-webkit-animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;animation:lds-roller 1.2s cubic-bezier(.5,0,.5,1) infinite;transform-origin:32px 32px}.td-loading-roller div:after{background:#000;border-radius:50%;content:\" \";display:block;height:6px;margin:-3px 0 0 -3px;position:absolute;width:6px}.td-loading-roller div:first-child{-webkit-animation-delay:-36ms;animation-delay:-36ms}.td-loading-roller div:first-child:after{left:50px;top:50px}.td-loading-roller div:nth-child(2){-webkit-animation-delay:-72ms;animation-delay:-72ms}.td-loading-roller div:nth-child(2):after{left:45px;top:54px}.td-loading-roller div:nth-child(3){-webkit-animation-delay:-.108s;animation-delay:-.108s}.td-loading-roller div:nth-child(3):after{left:39px;top:57px}.td-loading-roller div:nth-child(4){-webkit-animation-delay:-.144s;animation-delay:-.144s}.td-loading-roller div:nth-child(4):after{left:32px;top:58px}.td-loading-roller div:nth-child(5){-webkit-animation-delay:-.18s;animation-delay:-.18s}.td-loading-roller div:nth-child(5):after{left:25px;top:57px}.td-loading-roller div:nth-child(6){-webkit-animation-delay:-.216s;animation-delay:-.216s}.td-loading-roller div:nth-child(6):after{left:19px;top:54px}.td-loading-roller div:nth-child(7){-webkit-animation-delay:-.252s;animation-delay:-.252s}.td-loading-roller div:nth-child(7):after{left:14px;top:50px}.td-loading-roller div:nth-child(8){-webkit-animation-delay:-.288s;animation-delay:-.288s}.td-loading-roller div:nth-child(8):after{left:10px;top:45px}@-webkit-keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes lds-roller{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}"]
                },] }
    ];
    LoaderSpinnerComponent.ctorParameters = function () { return []; };
    LoaderSpinnerComponent.propDecorators = {
        active: [{ type: i0.Input }]
    };

    var FormatLinePipe = /** @class */ (function () {
        function FormatLinePipe() {
        }
        FormatLinePipe.prototype.transform = function (line, diffs) {
            if (!line) {
                return ' ';
            }
            if (!!diffs && diffs.length > 0) {
                /*diffs.forEach(diff => {
                  line = line.replace(diff, `<span class="highli">${diff}</span>`);
                });*/
            }
            return line
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/ /g, '&nbsp;');
        };
        return FormatLinePipe;
    }());
    FormatLinePipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'formatLine'
                },] }
    ];

    var NgxTextDiffModule = /** @class */ (function () {
        function NgxTextDiffModule() {
        }
        return NgxTextDiffModule;
    }());
    NgxTextDiffModule.decorators = [
        { type: i0.NgModule, args: [{
                    imports: [common.CommonModule, forms.FormsModule, scrolling.ScrollingModule],
                    declarations: [NgxTextDiffComponent, LoaderSpinnerComponent, FormatLinePipe, ContainerDirective],
                    exports: [NgxTextDiffComponent],
                },] }
    ];

    /*
     * Public API Surface of ngx-text-diff
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.NgxTextDiffComponent = NgxTextDiffComponent;
    exports.NgxTextDiffModule = NgxTextDiffModule;
    exports.NgxTextDiffService = NgxTextDiffService;
    exports.ɵa = ContainerDirective;
    exports.ɵb = LoaderSpinnerComponent;
    exports.ɵc = FormatLinePipe;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-text-diff.umd.js.map
